from discount import apply_discount

def test_10_percent_off_1000_is_900():
    assert apply_discount(1000, 10) == 900

def test_zero_percent_keeps_price():
    assert apply_discount(1000, 0) == 1000

def test_negative_price_raises():
    import pytest
    with pytest.raises(ValueError):
        apply_discount(-1, 10)
