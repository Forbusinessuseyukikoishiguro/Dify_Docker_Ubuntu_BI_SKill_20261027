def apply_discount(price, percent):
    if price < 0:
        raise ValueError("price must be >= 0")
    return price - price * percent // 100
