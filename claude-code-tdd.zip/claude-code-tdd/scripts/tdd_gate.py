#!/usr/bin/env python3
"""TDD のゲート（赤・緑・リファクタリングの判定）。テストは実行するが、テストファイルは変更しない。

使い方:
  python3 tdd_gate.py snapshot --tests tests --cmd "python3 -m pytest -q"
  python3 tdd_gate.py red      --tests tests --cmd "python3 -m pytest -q"
  python3 tdd_gate.py green    --tests tests --cmd "python3 -m pytest -q"
  python3 tdd_gate.py refactor --tests tests --cmd "python3 -m pytest -q"

- snapshot：テストファイルの指紋を .tdd/state.json に保存する
- red：テストが「失敗」すること（新しいテストが実装なしで落ちる）を確認する
- green：テストが全て成功し、テストファイルが snapshot から変わっていないことを確認する
- refactor：テストが全て成功し、テストファイルが変わっていないことを確認する
- 結果は TDD_LOG.md に追記する
終了コード：0＝合格、1＝不合格、2＝使い方の誤り
"""
import argparse
import datetime as dt
import hashlib
import json
import os
import shlex
import subprocess
import sys

STATE = '.tdd/state.json'
LOG = 'TDD_LOG.md'


def fingerprints(root):
    out = {}
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in ('__pycache__', '.pytest_cache')]
        for f in sorted(fn):
            if f.endswith(('.py', '.js', '.ts', '.java', '.go', '.rb')) or f.startswith('test_'):
                p = os.path.join(dp, f)
                out[p] = hashlib.sha256(open(p, 'rb').read()).hexdigest()[:16]
    return out


def run_tests(cmd):
    r = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr)


def log(stage, ok, note):
    stamp = dt.datetime.now().strftime('%Y-%m-%d %H:%M')
    line = f"- {stamp}｜{stage}｜{'合格' if ok else '不合格'}｜{note}\n"
    if not os.path.exists(LOG):
        open(LOG, 'w', encoding='utf-8').write('# TDD ログ\n\n')
    open(LOG, 'a', encoding='utf-8').write(line)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('stage', choices=['snapshot', 'red', 'green', 'refactor'])
    ap.add_argument('--tests', default='tests')
    ap.add_argument('--cmd', default='python3 -m pytest -q')
    a = ap.parse_args()
    os.makedirs('.tdd', exist_ok=True)

    if a.stage == 'snapshot':
        fp = fingerprints(a.tests)
        json.dump(fp, open(STATE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        log('snapshot', True, f'テストファイル {len(fp)} 件を記録')
        print(f'snapshot：{len(fp)} 件を記録')
        return 0

    if not os.path.exists(STATE) and a.stage != 'red':
        print('先に snapshot を実行してください', file=sys.stderr)
        return 2

    code, out = run_tests(a.cmd)
    summary = next((l for l in reversed(out.splitlines()) if l.strip()), '')

    if a.stage == 'red':
        ok = code == 1  # pytest：1 は失敗あり。5 はテストなし
        fp = fingerprints(a.tests)
        if not os.path.exists(STATE):
            json.dump(fp, open(STATE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        msg = '期待どおり失敗（赤）' if ok else ('全部成功：新しいテストが実装なしで通っている' if code == 0 else f'テストが実行できない（終了コード {code}）')
        log('red', ok, f'{msg}／{summary}')
        print(f'red：{msg}\n{summary}')
        print('失敗の理由が期待どおりかを読んでください（ImportError などは仕様の検証になっていない）')
        return 0 if ok else 1

    # green / refactor
    saved = json.load(open(STATE, encoding='utf-8'))
    now = fingerprints(a.tests)
    changed = sorted(set(k for k in set(saved) | set(now) if saved.get(k) != now.get(k)))
    tests_ok = code == 0
    no_cheat = not changed
    ok = tests_ok and no_cheat
    notes = []
    if not tests_ok:
        notes.append('テストが失敗している')
    if not no_cheat:
        notes.append('テストファイルが変更されている：' + ', '.join(changed[:5]))
    note = ('／'.join(notes) if notes else 'すべて成功、テストは変更されていない') + f'／{summary}'
    log(a.stage, ok, note)
    print(f'{a.stage}：{"合格" if ok else "不合格"}')
    for n in notes:
        print('  -', n)
    print(summary)
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
