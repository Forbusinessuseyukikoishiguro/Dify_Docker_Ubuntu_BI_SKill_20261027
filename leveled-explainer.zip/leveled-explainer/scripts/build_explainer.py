#!/usr/bin/env python3
"""レベル別の解説（explainer.json）を、Markdownにまとめ、話し方と根拠を検査する。

使い方:
  python3 build_explainer.py explainer.json --out 解説.md

入力の形は tests/sample_psych_safety.json を参照。
検査：禁止表現、レベルの欠落、根拠IDの登録状況（確認済みのみ）、数値の出典なし。
"""
import argparse
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
BANNED = [l.strip() for l in open(os.path.join(HERE, '..', 'reference', '禁止表現.txt'), encoding='utf-8') if l.strip()]
REGISTRY = {  # reference/根拠一覧.md の「確認済み」だけを登録する
    'edmondson1999': 'Edmondson, A. (1999). Psychological safety and learning behavior in work teams. Administrative Science Quarterly, 44(2), 350–383. DOI: 10.2307/2666999',
    'sweller1988': 'Sweller, J. (1988). Cognitive load during problem solving: Effects on learning. Cognitive Science, 12(2), 257–285. DOI: 10.1207/s15516709cog1202_4',
    'dunlosky2013': 'Dunlosky, J., Rawson, K. A., Marsh, E. J., Nathan, M. J., & Willingham, D. T. (2013). Improving students\' learning with effective learning techniques. Psychological Science in the Public Interest, 14(1), 4–58. DOI: 10.1177/1529100612453266',
    'roediger2006': 'Roediger, H. L., & Karpicke, J. D. (2006). Test-enhanced learning. Psychological Science, 17(3), 249–255. DOI: 10.1111/j.1467-9280.2006.01693.x',
    'ds100': 'デジタル社会推進標準ガイドライン群（デジタル庁）https://www.digital.go.jp/resources/standard_guidelines',
    'iso29148': 'ISO/IEC/IEEE 29148:2018 https://www.iso.org/standard/72089.html（適用の参考。認証の対象ではない）',
}
LEVELS = ['L1', 'L2', 'L3', 'L4']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('input')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d = json.load(open(a.input, encoding='utf-8'))
    warns = []
    text_all = json.dumps(d, ensure_ascii=False)

    for w in BANNED:
        if w in text_all:
            warns.append(f'禁止表現「{w}」が含まれています（reference/話し方.md の言い換えを使う）')
    for lv in d.get('levels_requested', LEVELS):
        if lv not in d.get('levels', {}):
            warns.append(f'レベル {lv} の説明がありません')
    for sid in d.get('sources', []):
        if sid not in REGISTRY:
            warns.append(f'根拠 {sid} は確認済み一覧にありません（使えません）')
    if d.get('sources') is None or not d.get('sources'):
        warns.append('根拠が一つもありません。数値や主張は「と考えられる」にしてください')
    if not re.search(r'(分かりにくい|質問|引っかか|疑問)', text_all):
        warns.append('質問を歓迎する一文がありません（reference/話し方.md）')
    for lv, body in d.get('levels', {}).items():
        if re.search(r'\d+(\.\d+)?\s*(%|％|人|件|倍)', body.get('text', '')) and not d.get('sources'):
            warns.append(f'{lv}：数値が含まれるが、根拠がありません')

    L = [f"# {d['term']}とは（{'・'.join(d.get('levels_requested', LEVELS))}）", '',
         f"**一言で**：{d['one_liner']}", '']
    for lv in d.get('levels_requested', LEVELS):
        if lv in d.get('levels', {}):
            L += [f"## {lv}：{d['levels'][lv]['title']}", '', d['levels'][lv]['text'], '']
    if d.get('pitfalls'):
        L += ['## よくある誤解', ''] + [f"- {p}" for p in d['pitfalls']] + ['']
    if d.get('questions'):
        L += ['## 確かめの問い', ''] + [f"{i}. {q}" for i, q in enumerate(d['questions'], 1)] + ['']
    if d.get('sources'):
        L += ['## 根拠（確認済みのもの）', ''] + [f"- {REGISTRY[s]}" for s in d['sources'] if s in REGISTRY] + ['']
    open(a.out, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print(f'wrote {a.out}（注意 {len(warns)} 件）')
    for w in warns:
        print('WARN:', w)


if __name__ == '__main__':
    main()
