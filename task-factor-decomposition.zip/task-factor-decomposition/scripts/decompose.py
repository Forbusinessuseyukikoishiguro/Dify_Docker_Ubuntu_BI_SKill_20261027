#!/usr/bin/env python3
"""目的のツリー（tree.json）から、WBS番号つきの一覧、Mermaid のツリー図、タスクCSV、検査結果を作る。

使い方:
  python3 decompose.py tree.json --out ./出力

tree.json: {"goal": "...", "children": [{"name": "...", "children": [...]}, ...], "done_when": "（葉のみ）"}
葉（children が無いノード）が作業。葉には done_when（完了条件）を書く。
"""
import argparse
import csv
import json
import os
import re

MAX_DEPTH = 4


def walk(node, number, depth, out, warns, path):
    kids = node.get('children', [])
    if kids:
        names = [k['name'] for k in kids]
        for n in set(names):
            if names.count(n) > 1:
                warns.append(('必須', '/'.join(path), f'同じ階層に同名の枝「{n}」（統合する）'))
    if depth > MAX_DEPTH:
        warns.append(('推奨', '/'.join(path), f'深さ {depth} が上限 {MAX_DEPTH} を超える（分けすぎの可能性）'))
    if not kids:
        if not node.get('done_when'):
            warns.append(('必須', '/'.join(path), '葉に完了条件（done_when）がない'))
        if not re.match(r'^[^\s]{1,}', node['name']) or not re.search(r'(する|作る|確認|入力|送る|決める|作成|実施|登録|削除|設定|記録|検査|整理|共有|承認|依頼|提出|書く|選ぶ|確定|更新|実行|修正|調べる|合わせる|記入|変更)$', node['name']):
            warns.append(('推奨', '/'.join(path), f'葉「{node["name"]}」が動詞で終わっていない（行動にする）'))
        out.append({'wbs': number, 'name': node['name'], 'done_when': node.get('done_when', ''), 'depth': depth})
    for i, k in enumerate(kids, 1):
        walk(k, f'{number}.{i}' if number else str(i), depth + 1, out, warns, path + [k['name']])


def mermaid(node):
    lines = ['flowchart LR']
    counter = [0]

    def nid():
        counter[0] += 1
        return f'N{counter[0]}'

    def rec(n, parent=None):
        me = nid()
        lines.append(f'  {me}["{n["name"]}"]')
        if parent:
            lines.append(f'  {parent} --> {me}')
        for k in n.get('children', []):
            rec(k, me)
    rec(node)
    return '\n'.join(lines) + '\n'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('tree')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    t = json.load(open(a.tree, encoding='utf-8'))
    os.makedirs(a.out, exist_ok=True)
    root = {'name': t['goal'], 'children': t.get('children', [])}
    leaves, warns = [], []
    walk(root, '', 0, leaves, warns, [t['goal']])
    wbs = ['# WBS（作業分解構造）', '', f"目的：{t['goal']}", '']
    wbs += [f"- {x['wbs']} {x['name']}（完了条件：{x['done_when'] or '要確認'}）" for x in leaves]
    open(os.path.join(a.out, 'WBS.md'), 'w', encoding='utf-8').write('\n'.join(wbs) + '\n')
    tree = ['# 目的のツリー', '', '```mermaid', mermaid(root).rstrip(), '```', '']
    open(os.path.join(a.out, 'ツリー.md'), 'w', encoding='utf-8').write('\n'.join(tree) + '\n')
    with open(os.path.join(a.out, 'タスク.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['WBS', 'タスク', '完了条件', '状態', '担当（役割）', '期限'])
        for x in leaves:
            w.writerow([x['wbs'], x['name'], x['done_when'], '未着手', '要確認', '要確認'])
    ck = ['# 検査結果', '']
    ck += (['| 判定 | 場所 | 指摘 |', '|---|---|---|'] + [f'| {l} | {p} | {m} |' for l, p, m in warns]) if warns else ['指摘なし（自動検査の範囲で）']
    open(os.path.join(a.out, '検査結果.md'), 'w', encoding='utf-8').write('\n'.join(ck) + '\n')
    must = sum(1 for x in warns if x[0] == '必須')
    print(f'wrote {a.out}（葉のタスク {len(leaves)} 件、指摘 {len(warns)} 件、必須 {must} 件）')


if __name__ == '__main__':
    main()
