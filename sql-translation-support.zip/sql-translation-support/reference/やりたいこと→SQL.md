# やりたいこと → SQL の型（SQLite 標準の書き方）

## 1. 月別の集計
```sql
SELECT substr(order_date, 1, 7) AS 月, COUNT(*) AS 件数, SUM(amount) AS 売上
FROM orders
WHERE status = '完了'
GROUP BY 月
ORDER BY 月;
```

## 2. 上位N件
```sql
SELECT customer_id, SUM(amount) AS 売上
FROM orders
WHERE status = '完了'
GROUP BY customer_id
ORDER BY 売上 DESC
LIMIT 10;
```

## 3. グループごとの最新の1件
```sql
SELECT customer_id, order_id, order_date, amount
FROM (
  SELECT o.*, ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY order_date DESC) AS rn
  FROM orders o
) t
WHERE rn = 1;
```
（SELECT * は避け、必要な列を書く。ウィンドウ関数は SQLite 3.25 以降、MySQL 8.0 以降、PostgreSQL、SQL Server で使える）

## 4. 割合（構成比）
```sql
SELECT region, COUNT(*) AS 件数,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM customers), 1) AS 構成比
FROM customers
GROUP BY region;
```

## 5. 前月比
```sql
WITH m AS (
  SELECT substr(order_date, 1, 7) AS 月, SUM(amount) AS 売上
  FROM orders WHERE status = '完了' GROUP BY 月
)
SELECT 月, 売上, 売上 - LAG(売上) OVER (ORDER BY 月) AS 差
FROM m;
```

## 注意（共通）
- 分母が0になる箇所は、NULLIF(分母, 0) で守る。
- 期間の境界は「以上・未満」で書く（BETWEEN は終端を含むため、日時では誤りやすい）。
- 指標の定義（返品の扱い、重複の除外）を、SQL のコメントに一文で書く。
