/* 月別の売上（返品を除く） */
SELECT
TOP 10
  SUBSTRING(order_date, 1, 7) AS 月,
  COUNT_BIG(*) AS 件数,
  SUM(amount) AS 売上
FROM orders
WHERE
  status = '完了'
GROUP BY
  月
ORDER BY
  月 DESC
