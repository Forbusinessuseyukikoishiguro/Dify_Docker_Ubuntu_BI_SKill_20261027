/* 月別の売上（返品を除く） */
SELECT
  SUBSTRING(order_date FROM 1 FOR 7) AS 月,
  COUNT(*) AS 件数,
  SUM(amount) AS 売上
FROM orders
WHERE
  status = '完了'
GROUP BY
  月
ORDER BY
  月 DESC NULLS LAST
LIMIT 10
