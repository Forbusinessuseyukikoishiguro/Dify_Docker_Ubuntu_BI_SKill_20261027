CREATE TABLE orders (order_id INTEGER, customer_id INTEGER, order_date TEXT, amount TEXT, product1 TEXT, product2 TEXT, status TEXT);
CREATE TABLE customers (customer_id INTEGER, region TEXT, email TEXT, tags TEXT);
INSERT INTO orders VALUES (1, 1, '2026-01-05', '1000', 'A', 'B', '完了');
INSERT INTO orders VALUES (2, 2, '2026-01-09', '2500', 'C', NULL, '完了');
INSERT INTO orders VALUES (3, 1, '2026-02-11', '900', 'A', NULL, '返品');
INSERT INTO customers VALUES (1, '東京', 'a@example.com', 'vip,new,web');
INSERT INTO customers VALUES (2, '大阪', 'b@example.com', 'web,repeat,sale');
INSERT INTO customers VALUES (3, '東京', 'c@example.com', 'new,web,sale');
