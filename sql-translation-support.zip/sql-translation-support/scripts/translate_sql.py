#!/usr/bin/env python3
"""SQL を複数の方言へ翻訳し、要確認の箇所を示す（sqlglot を使用）。

使い方:
  python3 scripts/translate_sql.py 基本.sql --from sqlite --to postgres mysql tsql --out ./翻訳

- 翻訳結果は各方言のファイルに保存する。
- 意味が変わりうる箇所（日付、連結、ゼロ除算、大文字小文字、NULL）を警告する。
- 翻訳の正しさは、対象の DB で実行して確かめること（この script は実行しない）。
"""
import argparse
import os
import re

import sqlglot

RISK = [
    (r'\bsubstr\b|\bSUBSTRING\b', '部分文字列：添字の扱いを確認'),
    (r'\|\|', '文字列連結：NULL を含む時の結果を確認（DBにより NULL）'),
    (r'\bCONCAT\b', 'CONCAT：NULL の扱いを確認'),
    (r'/\s*\(?\s*SELECT|/\s*\w+', '割り算：ゼロ除算と整数除算の扱いを確認'),
    (r'\bLIKE\b|\bILIKE\b', '文字の比較：大文字小文字の扱いが DB で違う'),
    (r'\bdate\(|\bstrftime\(|\bDATE_FORMAT\b|\bFORMAT\(', '日付関数：書式と境界（23:59:59 等）を確認'),
    (r'\bLIMIT\b|\bTOP\b|\bFETCH\b', '件数制限：意味は同じ。並び順と同順位の扱いを確認'),
    (r'\bCOUNT\s*\(\s*\w+\s*\)', 'COUNT(列)：NULL を数えない。COUNT(*) との違いを確認'),
    (r'\bORDER\s+BY\b', 'ORDER BY：NULL の並び順は DB の既定が違う（翻訳で NULLS FIRST/LAST が付くことがある）'),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sql')
    ap.add_argument('--from', dest='src', default='sqlite')
    ap.add_argument('--to', nargs='+', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    text = open(a.sql, encoding='utf-8').read()
    os.makedirs(a.out, exist_ok=True)
    report = [f'# 翻訳レポート（元：{a.src}）', '', f'元のファイル：{a.sql}', '']
    for dst in a.to:
        try:
            out = sqlglot.transpile(text, read=a.src, write=dst, pretty=True)
        except Exception as e:
            report += [f'## {dst}：翻訳できませんでした', '', f'- {e.__class__.__name__}: {str(e)[:200]}', '']
            continue
        path = os.path.join(a.out, f'{dst}.sql')
        body = '\n\n'.join(out) + '\n'
        open(path, 'w', encoding='utf-8').write(body)
        report += [f'## {dst}', '', f'保存：{path}', '', '```sql', body.rstrip(), '```', '']
        warns = [msg for pat, msg in RISK if re.search(pat, text, re.I)]
        report += ['要確認：'] + ([f'- {w}' for w in warns] if warns else ['- 自動の検出では特記事項なし（それでも DB で実行して確認する）']) + ['']
    report += ['## 検証の状態', '', '- この変換は自動です。対象の DB で、元と翻訳後の結果が一致するかを確認してください。',
               '- 未検証の方言は「未検証」と書いて報告してください。']
    open(os.path.join(a.out, '翻訳レポート.md'), 'w', encoding='utf-8').write('\n'.join(report) + '\n')
    print(f'wrote {a.out}/翻訳レポート.md')


if __name__ == '__main__':
    main()
