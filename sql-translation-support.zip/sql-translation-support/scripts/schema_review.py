#!/usr/bin/env python3
"""テーブル定義（DDL ファイル、または SQLite の DB）を設計観点で点検する（読み取り専用）。

使い方:
  python3 scripts/schema_review.py テーブル定義.sql --out 設計レビュー.md
  python3 scripts/schema_review.py データ.db --out 設計レビュー.md

観点は reference/テーブル設計.md と対応する。
"""
import argparse
import re
import sqlite3

PII = re.compile(r'(?i)(email|mail|phone|tel|address|住所|電話|氏名|name|birth|口座|card)')


def load(path):
    if path.lower().endswith('.db'):
        return sqlite3.connect(f'file:{path}?mode=ro', uri=True)
    con = sqlite3.connect(':memory:')
    con.executescript(open(path, encoding='utf-8').read())
    return con


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('source')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    con = load(a.source)
    tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    findings = []

    def add(level, where, msg, basis):
        findings.append((level, where, msg, basis))

    names = set(tables)
    for t in tables:
        cols = con.execute(f'PRAGMA table_info("{t}")').fetchall()
        pk = [c[1] for c in cols if c[5]]
        if not pk:
            add('必須', t, '主キーがない', 'テーブル設計 基本（主キー）')
        cnames = [c[1] for c in cols]
        # 繰り返しの列（product1, product2 など）
        groups = {}
        for c in cnames:
            m = re.match(r'^(.*?)(\d+)$', c)
            if m and m.group(1):
                groups.setdefault(m.group(1), []).append(c)
        for base, members in groups.items():
            if len(members) >= 2:
                add('必須', t, f'繰り返しの列：{", ".join(members)}', 'テーブル設計（繰り返しの列は別テーブルへ）')
        for c in cols:
            name, ctype, notnull = c[1], (c[2] or '').upper(), c[3]
            if re.search(r'(amount|price|金額|売上|total)', name, re.I) and 'INT' not in ctype and 'REAL' not in ctype and 'NUM' not in ctype and 'DEC' not in ctype:
                add('必須', f'{t}.{name}', f'金額らしい列の型が数値でない（{ctype or "未指定"}）', 'テーブル設計（型の不一致）')
            if name.lower().endswith('_id') and name not in pk and notnull == 0:
                ref = name[:-3]
                target = ref if ref in names else (ref + 's' if (ref + 's') in names else None)
                if target and target != t:
                    add('推奨', f'{t}.{name}', '外部キーの候補だが、NOT NULL と参照の定義がない', 'テーブル設計（外部キー）')
            if PII.search(name):
                add('推奨', f'{t}.{name}', '個人情報らしい列（分析用の表に入れていないか確認）', 'テーブル設計（個人情報の分離）')
        # 値の点検（カンマ区切り、ISO日付の文字列化）
        sample = con.execute(f'SELECT * FROM "{t}" LIMIT 50').fetchall()
        for i, c in enumerate(cols):
            vals = [r[i] for r in sample if isinstance(r[i], str)]
            if vals and sum(1 for v in vals if ',' in v) >= max(3, len(vals) // 2):
                add('推奨', f'{t}.{c[1]}', 'カンマ区切りの値が多い（1列に複数の値）', 'テーブル設計（1列に複数の値）')
            if vals and sum(1 for v in vals if re.match(r'^\d{4}-\d{2}-\d{2}', v)) >= max(3, len(vals) // 2) and 'DATE' not in (c[2] or '').upper():
                add('推奨', f'{t}.{c[1]}', '日付が文字列で入っている（日付型の検討）', 'テーブル設計（型）')
    print(f'{len(tables)} テーブル、指摘 {len(findings)} 件')
    L = ['# テーブル設計レビュー', '', f'対象：{a.source}　／　テーブル数：{len(tables)}', '']
    if not findings:
        L.append('指摘はありません（自動チェックの範囲で）。')
    else:
        L += ['| 判定 | 場所 | 指摘 | 根拠 |', '|---|---|---|---|']
        for lv, w, m, b in sorted(findings, key=lambda x: (x[0] != '必須', x[1])):
            L.append(f'| {lv} | {w} | {m} | {b} |')
    L += ['', '注意：自動の点検は候補の提示。設計の変更は、業務への影響を確認して承認を得てから行う。']
    open(a.out, 'w', encoding='utf-8').write('\n'.join(L) + '\n')


if __name__ == '__main__':
    main()
