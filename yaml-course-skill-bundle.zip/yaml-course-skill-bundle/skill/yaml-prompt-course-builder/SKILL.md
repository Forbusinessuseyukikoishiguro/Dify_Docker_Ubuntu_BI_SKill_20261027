---
name: yaml-prompt-course-builder
description: YAML×生成AI画像プロンプトをテーマにした初心者向け講座（Udemy・研修）を、受講生用PPT＋講師用マークダウン＋配布YAMLの一式で作るスキル。「楽しい↔むずかしい」の波（8ステップのスロープ設計）、各スライドの問いかけ、YAML文法を4つの箱で教えるMECE構成、具体と抽象・画風レシピ・採点表のボーナス/特典、YAML例のパース検証までをカバー。「YAML講座を作って」「画像プロンプトの講座にして」「文法ルールを前半座学に入れて」「スキル追加ミッション／特典を足して」「受講生用と講師用の資料」等で使う。
---

# YAML×画像プロンプト講座ビルダー

初心者（主に文系・非IT）向けに、YAMLで生成AIの画像プロンプトを整理・調整する講座を、**検証済みの教材一式**として作る。本スキルは、実際に作成した講座（「具体と抽象をYAMLで調整する」：約100分・48枚）の手順と部品をそのまま再利用できる形にしたもの。

## 成果物（標準セット）
1. 受講生用PPTX（本編＋任意のボーナス＋特典＋補足コラム＋参考資料）
2. 講師用マークダウン（設計・台本・答え・確認テスト・つまずき対応・短縮プラン・IT差分・Udemy掲載文案・早見表）
3. 配布YAML（特典：画風レシピ集 など）
4. （任意）Qiita/Zenn向け記事、講師用Word台本などは別途。

## 最初にやること（質問は最小限。足りなければ仮置きして明記）
- 題材（例：食べ物・風景・商品）と、受講生から受け取った画像・YAML素材の有無
- 主ペルソナ（既定：文系・非IT初心者）／副ペルソナ（IT受講生の有無）
- 本編の長さ（既定：約100分）／ボーナス・特典の要否
- 使う画像生成サービスは**特定しない**（受講生が各自使えるもの）
→ `assets/course_config_template.yaml` を埋めて設計シートにする。

## ワークフロー
1. **設計**：`references/01_course-design.md`。8ステップの楽しさ・むずかしさを決め、ひと休みの回と山場（ヒント3段階）を置く。時間の合計を確認。
2. **文法パート**：`references/02_grammar-mece-boxes.md`。文法は「4つの箱」（行の種類／字下げ／値の書き方／使える文字）に分け、7つのよくあるミスを全て箱に割り当てる。別資料の文法項目を取り込むときも、必ず4つの箱のどれかに割り当てる（重複・漏れを作らない）。
3. **具体と抽象・画風**：`references/03_concrete-abstract-teaching.md`。3レベル、項目別調整、採点表（独自の目安と明記）、画風7部品、レシピ集。
4. **教材YAMLを先に作って検証**（スライドを作る前）：
   - `python3 scripts/validate_yaml_blocks.py assets/snippets`（わざと壊した例は名前に `bug` を含める）
   - `python3 scripts/check_yaml_behaviors.py`（ミスの挙動は必ずこの結果を根拠に書く）
5. **受講生用PPT**：`assets/deck_lib.js` ＋ `assets/build_deck_example.js` を元に、`references/04_slide-patterns.md` の種別カタログでスライドを組む。
   - 実行：`NODE_PATH=$(npm root -g) node build.js`
   - 確認：`bash scripts/render_and_qa.sh deck.pptx` → コンタクトシートを**全部目視**。
6. **講師用マークダウン**：`assets/instructor_template.md` と `references/05_instructor-md-guide.md`。答えは講師用にのみ載せる。書き終えたら `validate_yaml_blocks.py` で全YAMLブロックを再検証。
7. **ボーナス／特典**（要望があれば）：スキル追加ミッション（採点・リスト追加）、画風レシピ集（`assets/style_recipe_collection.yaml` を元に）。
8. **整合チェック**：時間・枚数・PPT番号・★が受講生用と講師用で一致しているか（`references/04` の完成時チェック）。スライドを挿入したら `scripts/shift_ppt_refs.py` で参照番号をずらす。
9. **納品**：`/mnt/user-data/outputs` に保存して提示。前提・解釈した点・手元になかった素材を短く報告（`references/06_verification-and-honesty.md`）。

## 守るルール（要点）
- 教材内のYAMLはすべてパース検証する。文法ミスの結果は確認した内容だけ書く（「PyYAMLでの確認結果。処理系により異なる」と添える）。
- YAMLは画像生成AIに**必須ではない**。3レベル・1〜5点・high/low は人間が整理する**目安**で、AIの内部設定や規格ではない。
- 画像とYAMLの因果を断定しない。AIの出力は毎回変わり、同じ結果になる保証はない。画像内の文字は確認が必要。
- 作家名・作品名・キャラクター名・ブランド名・実在人物名を、演習・レシピに入れない。
- 画像がない比較は「画像は手元にありません」と明記する。出典は開いて確認してから使う。設計理論は名称のみ（未確認の数値・論文詳細は書かない）。
- 各スライド下部に問いかけ。答えは受講生用に載せない。

## ファイル構成
```
SKILL.md
references/  01 設計 / 02 文法4つの箱 / 03 具体と抽象・画風 / 04 スライド / 05 講師用MD / 06 検証と誠実さ
scripts/     validate_yaml_blocks.py / check_yaml_behaviors.py / contact_sheet.py / render_and_qa.sh / shift_ppt_refs.py
assets/      deck_lib.js / build_deck_example.js / course_config_template.yaml / instructor_template.md
             style_recipe_collection.yaml / snippets/（検証済みYAML例）
```

## 環境メモ
- PPT生成は pptxgenjs（Node）。検証・PDF化は環境の pptx スキルの `validate.py` / `soffice.py`（`render_and_qa.sh` 内のパスは環境に合わせて調整）。
- PyYAML が必要：`pip install pyyaml --break-system-packages`。
- 日本語フォントは PowerPoint 側で解決される。LibreOffice での確認描画は代替フォントになるため、見た目が少し変わる。
