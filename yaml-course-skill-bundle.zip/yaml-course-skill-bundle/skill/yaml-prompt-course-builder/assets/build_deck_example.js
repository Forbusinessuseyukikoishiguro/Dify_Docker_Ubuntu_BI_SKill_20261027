/**
 * build_deck_example.js ― deck_lib.js を使った最小の実例（6枚）
 * 実行: cd assets && NODE_PATH=$(npm root -g) node build_deck_example.js
 * 新しい講座では、このファイルをコピーして、スライドを course_config の STEP 構成に合わせて足していく。
 */
const D = require("./deck_lib");
const deck = D.createDeck({ footer: "サンプル講座 ― 受講生用", snipDir: "snippets", title: "サンプル" });
const { W } = D;

// 1) タイトル（濃紺）
{
  const s = deck.base(D.NAVY);
  s.addText("具体と抽象を\nYAMLで調整する", { x: 0.7, y: 1.8, w: 8, h: 1.9, fontSize: 38, bold: true, color: "FFFFFF", fontFace: D.BODY, margin: 0 });
  s.addText("文系初心者のための8ステップ講座", { x: 0.7, y: 3.9, w: 8, h: 0.5, fontSize: 18, color: D.CODE_FG, fontFace: D.BODY, margin: 0 });
}

// 2) 4つの箱（文法の地図）
{
  const s = deck.base();
  deck.head(s, 2, "文法ルールの地図：4つの箱", 4, 2);
  const boxes = [["① 行の種類", "1行を、どう書く？"], ["② 字下げ", "行と行の関係は？"], ["③ 値の書き方", "中身を、どう書く？"], ["④ 使える文字", "どの文字を使う？"]];
  boxes.forEach((b, i) => deck.card(s, 0.6 + (i % 2) * 6.15, 1.4 + Math.floor(i / 2) * 1.9, 5.95, 1.7, b[0], b[1], { bsize: 15 }));
  deck.bar(s, 0.6, 5.4, W - 1.2, 0.7, "どんな文法ミスも、4つの箱のどれか1つに入ります。");
  deck.qbox(s, 0.6, 6.2, W - 1.2, "困ったら、まず「どの箱の話？」と考えよう。", 0.7);
}

// 3) コード＋カード
{
  const s = deck.base();
  deck.head(s, 3, "実物を読む", 3, 4);
  deck.code(s, 0.6, 1.3, 5.9, 4.5, deck.snip("g_read"), 13);
  deck.card(s, 6.8, 1.3, 5.95, 2.0, "読み方のポイント", "title はキーと値（箱①）。\nsubject の下の字下げ行は子（箱②）。", { bsize: 13 });
  deck.qbox(s, 0.6, 6.0, W - 1.2, "「background」の下の行は、誰の子？", 0.85);
}

// 4) 表（ミス総覧）
{
  const s = deck.base();
  deck.head(s, 3, "よくあるミスと箱", 3, 4);
  deck.table(s, [["ミス", "箱", "直し方"], ["全角のコロン", "④", "半角「:」に"], ["字下げの幅がバラバラ", "②", "同じ階層は同じ幅に"]],
    0.6, 1.4, W - 1.2, [5.0, 1.5, 5.63], 0.6, { centerCols: [1] });
  deck.qbox(s, 0.6, 5.9, W - 1.2, "7つのミスは、4つの箱のどれかに入っていますか？", 0.85);
}

// 5) ワークショップ（ヒント3段階＋記入欄）
{
  const s = deck.base();
  deck.head(s, 6, "ワークショップ①：書いてみよう", 2, 5);
  s.addShape("rect", { x: 0.6, y: 1.25, w: W - 1.2, h: 0.95, fill: { color: D.NAVY }, line: { type: "none" } });
  s.addText("Q. 好きな食べ物で、主役は具体的・背景は抽象的な YAML を作ってください。", { x: 0.85, y: 1.25, w: W - 1.7, h: 0.95, valign: "middle", fontSize: 16, bold: true, color: "FFFFFF", fontFace: D.BODY, margin: 0 });
  deck.hints(s, 0.6, 2.45, [["ヒント1", "まず主役の名前だけ決める。"], ["ヒント2", "subject と background の2つの箱を作る。"], ["ヒント3", "background は形を細かく決めない。"]]);
  deck.blank(s, 7.7, 2.45, 5.05, "記入欄");
  deck.qbox(s, 0.6, 6.15, W - 1.2, "手が止まったら、ヒントを1つだけ開く。", 0.75);
}

// 6) 達成バッジ（濃紺）
{
  const s = deck.base(D.NAVY);
  s.addText("具体と抽象を操るYAMLデザイナー", { x: 0, y: 3.2, w: W, h: 0.8, align: "center", fontSize: 30, bold: true, color: "FFFFFF", fontFace: D.BODY, margin: 0 });
}

deck.save("example_deck.pptx").then(() => console.log("written example_deck.pptx,", deck.pageCount(), "slides"));
