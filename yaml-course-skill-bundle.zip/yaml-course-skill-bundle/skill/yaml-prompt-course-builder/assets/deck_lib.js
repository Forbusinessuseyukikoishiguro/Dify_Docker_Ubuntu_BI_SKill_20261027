/**
 * deck_lib.js ― 受講生用PPT（YAML×生成AI画像プロンプト講座）の共通部品
 *
 * 使い方:
 *   const D = require("./deck_lib");
 *   const deck = D.createDeck({ footer: "講座名 ― 受講生用", snipDir: "snippets" });
 *   const s = deck.base();                       // 白地スライド（引数に D.NAVY を渡すと濃紺）
 *   deck.head(s, 3, "タイトル", 3, 4);           // STEP 3/8、楽しさ★3、むずかしさ★4
 *   deck.code(s, x, y, w, h, deck.snip("g_read"), 13);
 *   deck.qbox(s, 0.6, 5.9, D.W - 1.2, "問いかけ文", 0.85);
 *   await deck.save("out.pptx");
 *
 * 実行: NODE_PATH=$(npm root -g) node your_build.js   （pptxgenjs が必要）
 * 注意: 日本語フォントは "Yu Gothic"、コードは "Consolas"（PowerPoint側で解決される）。
 *       LibreOffice での確認用レンダリングでは代替フォントになり、見た目が少し変わる。
 */
const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");

const C = {
  NAVY: "1F2A44", ROSE: "C9788A", CREAM: "FAF6EF", GOLD: "8A6D1E", SAND: "EFE6D6",
  TEXT: "2B2B2B", MUTED: "6F695E", CODE_FG: "F4EFE6", LINE: "E2D9C8", WHITE: "FFFFFF", GOLD_BADGE: "B8860B",
};
const W = 13.33, H = 7.5;
const BODY = "Yu Gothic", MONO = "Consolas";
const stars = (n) => "★".repeat(n) + "☆".repeat(5 - n);

function createDeck(opts) {
  const o = Object.assign({ footer: "受講生用", snipDir: "snippets", stepTotal: 8, title: "" }, opts || {});
  const p = new pptxgen();
  p.layout = "LAYOUT_WIDE";
  if (o.title) p.title = o.title;
  let pageNo = 0;

  const snip = (name) => fs.readFileSync(path.join(o.snipDir, name.includes(".") ? name : name + ".yaml"), "utf-8").trimEnd();

  function base(bg) {
    const s = p.addSlide();
    s.background = { color: bg || C.CREAM };
    pageNo += 1;
    const dark = bg === C.NAVY;
    s.addText(o.footer, { x: 0.5, y: H - 0.4, w: 7, h: 0.28, fontSize: 10, color: dark ? "B9B4A8" : C.MUTED, fontFace: BODY, margin: 0 });
    s.addText(String(pageNo).padStart(2, "0"), { x: W - 1.0, y: H - 0.4, w: 0.5, h: 0.28, fontSize: 10, color: dark ? "B9B4A8" : C.MUTED, align: "right", fontFace: BODY, margin: 0 });
    return s;
  }

  // kind: "step" | "bonus" | "tokuten"
  function headGeneric(s, badge, badgeColor, ruleColor, title, fun, diff) {
    s.addShape("roundRect", { x: 0.55, y: 0.38, w: 1.55, h: 0.4, fill: { color: badgeColor }, line: { type: "none" }, rectRadius: 0.08 });
    s.addText(badge, { x: 0.55, y: 0.38, w: 1.55, h: 0.4, align: "center", valign: "middle", bold: true, fontSize: 12, color: C.WHITE, fontFace: BODY, margin: 0 });
    s.addText(title, { x: 2.3, y: 0.3, w: 7.4, h: 0.56, valign: "middle", bold: true, fontSize: 24, color: C.TEXT, fontFace: BODY, margin: 0 });
    s.addText([
      { text: `楽しさ ${stars(fun)}`, options: { color: C.ROSE, breakLine: true } },
      { text: `むずかしさ ${stars(diff)}`, options: { color: C.NAVY } },
    ], { x: 9.85, y: 0.28, w: 2.95, h: 0.62, align: "right", fontSize: 12, bold: true, fontFace: BODY, margin: 0 });
    s.addShape("line", { x: 0.55, y: 1.02, w: W - 1.1, h: 0, line: { color: ruleColor, width: 1.5 } });
  }
  const head = (s, step, title, fun, diff) => headGeneric(s, `STEP ${step} / ${o.stepTotal}`, C.NAVY, C.ROSE, title, fun, diff);
  const headBonus = (s, title, fun, diff) => headGeneric(s, "BONUS", C.ROSE, C.NAVY, title, fun, diff);
  const headTok = (s, title, fun, diff) => headGeneric(s, "特典", C.GOLD_BADGE, C.GOLD_BADGE, title, fun, diff);

  function plainTitle(s, title) {
    s.addText(title, { x: 0.6, y: 0.4, w: 11, h: 0.6, fontSize: 28, bold: true, color: C.TEXT, fontFace: BODY, margin: 0 });
    s.addShape("line", { x: 0.6, y: 1.05, w: W - 1.2, h: 0, line: { color: C.ROSE, width: 1.5 } });
  }

  function code(s, x, y, w, h, text, size) {
    s.addShape("rect", { x, y, w, h, fill: { color: C.NAVY }, line: { type: "none" } });
    s.addText(text, { x: x + 0.15, y: y + 0.1, w: w - 0.3, h: h - 0.2, fontFace: MONO, fontSize: size || 12, color: C.CODE_FG, valign: "top", margin: 0, lineSpacingMultiple: 1.05, fit: "shrink" });
  }

  // 問いかけボックス（各スライドの下部。難易度の波を作る道具）
  function qbox(s, x, y, w, text, h) {
    const hh = h || 0.85;
    s.addShape("rect", { x, y, w: 0.07, h: hh, fill: { color: C.ROSE }, line: { type: "none" } });
    s.addShape("rect", { x: x + 0.07, y, w: w - 0.07, h: hh, fill: { color: C.SAND }, line: { type: "none" } });
    s.addText("問いかけ", { x: x + 0.28, y: y + 0.07, w: 2, h: 0.28, bold: true, fontSize: 11, color: C.GOLD, fontFace: BODY, margin: 0 });
    s.addText(text, { x: x + 0.28, y: y + 0.34, w: w - 0.5, h: hh - 0.4, fontSize: 13.5, bold: true, color: C.TEXT, fontFace: BODY, margin: 0, valign: "top" });
  }

  function card(s, x, y, w, h, title, body, opt) {
    const q = opt || {};
    s.addShape("rect", { x, y, w, h, fill: { color: C.WHITE }, line: { color: C.LINE, width: 1 }, shadow: { type: "outer", color: "000000", opacity: 0.08, blur: 4, offset: 2, angle: 90 } });
    s.addText(title, { x: x + 0.2, y: y + 0.12, w: w - 0.4, h: 0.4, bold: true, fontSize: q.tsize || 15, color: q.tcolor || C.NAVY, fontFace: BODY, margin: 0 });
    s.addText(body, { x: x + 0.2, y: y + 0.55, w: w - 0.4, h: h - 0.65, fontSize: q.bsize || 13, color: C.TEXT, fontFace: BODY, margin: 0, valign: "top", lineSpacingMultiple: 1.15 });
  }

  // 記入欄（ラベル＋点線）
  function blank(s, x, y, w, label) {
    s.addText(label, { x, y, w, h: 0.32, fontSize: 12, color: C.MUTED, fontFace: BODY, margin: 0, bold: true });
    s.addShape("line", { x, y: y + 0.72, w, h: 0, line: { color: "A89F8D", width: 1, dashType: "dash" } });
  }

  // 表。rows[0] は見出し行。colW の合計 = w にする。
  function table(s, rows, x, y, w, colW, rowH, opt) {
    const q = Object.assign({ size: 12.5, monoCols: [], centerCols: [], boldCols: [0] }, opt || {});
    const tr = rows.map((r, ri) => r.map((c, ci) => ({
      text: c,
      options: {
        fontFace: q.monoCols.includes(ci) && ri > 0 ? MONO : BODY, fontSize: q.size,
        bold: ri === 0 || q.boldCols.includes(ci), color: ri === 0 ? C.WHITE : C.TEXT,
        fill: { color: ri === 0 ? C.NAVY : (ri % 2 ? C.WHITE : C.SAND) }, valign: "middle",
        align: q.centerCols.includes(ci) ? "center" : "left",
      },
    })));
    s.addTable(tr, { x, y, w, colW, rowH, border: { type: "solid", color: C.LINE, pt: 0.75 } });
  }

  // 濃紺の強調バー（「コツ」「注意」など）
  function bar(s, x, y, w, h, text, size) {
    s.addShape("rect", { x, y, w, h, fill: { color: C.NAVY }, line: { type: "none" } });
    s.addText(text, { x: x + 0.3, y, w: w - 0.6, h, valign: "middle", bold: true, fontSize: size || 14, color: C.WHITE, fontFace: BODY, margin: 0 });
  }

  // 番号つきヒント（H1〜H3）。ワークショップの安全網
  function hints(s, x, y, items) {
    items.forEach((h, i) => {
      const yy = y + i * 0.95;
      s.addShape("ellipse", { x, y: yy, w: 0.5, h: 0.5, fill: { color: C.ROSE }, line: { type: "none" } });
      s.addText(String(i + 1), { x, y: yy, w: 0.5, h: 0.5, align: "center", valign: "middle", bold: true, fontSize: 15, color: C.WHITE, fontFace: BODY, margin: 0 });
      s.addText(h[0], { x: x + 0.65, y: yy - 0.03, w: 2, h: 0.3, bold: true, fontSize: 13, color: C.TEXT, fontFace: BODY, margin: 0 });
      s.addText(h[1], { x: x + 0.65, y: yy + 0.27, w: 4.8, h: 0.6, fontSize: 12.5, color: C.MUTED, fontFace: BODY, margin: 0, valign: "top" });
    });
  }

  return { p, base, head, headBonus, headTok, plainTitle, code, qbox, card, blank, table, bar, hints, snip,
           pageCount: () => pageNo, save: (file) => p.writeFile({ fileName: file }) };
}

module.exports = Object.assign({ createDeck, W, H, BODY, MONO, stars }, C);
