#!/usr/bin/env python3
"""文法ミスが実際にどう読まれるかを、PyYAMLで確認して表示する。

講師用資料に「何が起きるか」を書く前に必ず実行し、結果を根拠にすること。
（処理系やバージョンによって挙動は異なる。資料には「PyYAMLでの確認結果」と書く）
"""
import sys
try:
    import yaml
except ImportError:
    sys.exit("PyYAML が必要です: pip install pyyaml --break-system-packages")

CASES = [
    ("全角コロン（単独の行）", 'subject： "ウィンナーパン"\n'),
    ("全角コロン（ほかの項目と並ぶ）", 'title: "a"\nsubject： "ウィンナーパン"\n'),
    ("コロンの後ろにスペースなし（子の行が続く）", 'background:\n  place:"北欧の港町"\n  mood: "穏やか"\n'),
    ("コロンの後ろにスペースなし（親の下に1行だけ）", 'subject:\n  name:"ソーセージパン"\nbackground: "北欧の港町"\n'),
    ("字下げの幅が2と3", 'background:\n  place: "a"\n   mood: "b"\n'),
    ("ハイフンの後ろにスペースなし", 'objects:\n  -"黄金色のパン"\n  - "白黒のごま"\n'),
    ("引用符の閉じ忘れ", 'background:\n  place: "北欧の港町\n'),
    ("曲がった引用符 “ ”", 'a: \u201cx\u201d\n'),
    ("数字（引用符なし）", 'specificity: 2\n'),
    ("数字（引用符あり）", 'specificity: "2"\n'),
    ("> 複数行（行の間に空白が入る）", 'concept: >\n  繊細な水彩で、\n  温かい午後を描く。\n'),
    ("色コードを引用符なしで", 'c: #C6A15B\n'),
    ("色コードを引用符ありで", 'c: "#C6A15B"\n'),
    ("値に「: 」を含み引用符なし", 'title: 具体と抽象: 調整\n'),
    ("値に「: 」を含み引用符あり", 'title: "具体と抽象: 調整"\n'),
    ("全角スペースで字下げ", 'a:\n\u3000b: 1\n'),
    ("タブで字下げ", 'a:\n\tb: 1\n'),
    ("yes / no（YAML 1.1系の真偽値）", 'answer: no\nflag: yes\n'),
]

print("PyYAML", yaml.__version__)
for name, src in CASES:
    try:
        print(f"{name:40s} -> {yaml.safe_load(src)!r}")
    except Exception as e:
        lines = str(e).splitlines()
        print(f"{name:40s} -> ERROR {type(e).__name__}: {lines[0]}")
