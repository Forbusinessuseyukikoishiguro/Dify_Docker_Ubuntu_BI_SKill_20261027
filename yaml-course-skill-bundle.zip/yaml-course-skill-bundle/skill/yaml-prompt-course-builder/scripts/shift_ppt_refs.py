#!/usr/bin/env python3
"""スライドを挿入したあと、講師用マークダウン内の「PPT 12」のような参照番号を一括でずらす。

使い方: python3 shift_ppt_refs.py <md> <しきい値> <ずらす数>
例:     python3 shift_ppt_refs.py instructor.md 10 7   # 10枚目以降を +7

対応する書き方:
  - 「PPT 12」「PPT 12〜14」「PPT 24、25」「PPT 1→2」
  - 時間表の行  | 0:00–0:05 | 12〜14 | ...
手動確認が必要なもの（このスクリプトは直さない）:
  - 「PPT 24、25（早見表のみ）、29」のように、文章を挟んで番号が続く箇所
実行後は必ず差分を目視確認すること。
"""
import re, sys, pathlib
path, threshold, delta = pathlib.Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
text = path.read_text(encoding="utf-8")
shift = lambda n: n + delta if n >= threshold else n
seq = re.compile(r"PPT\s*\d+(?:\s*(?:〜|→|・|、)\s*\d+)*")
text = seq.sub(lambda m: re.sub(r"\d+", lambda x: str(shift(int(x.group(0)))), m.group(0)), text)
row = re.compile(r"(\| \d:\d\d–\d:\d\d \| )([\d〜]+)( \|)")
text = row.sub(lambda m: m.group(1) + re.sub(r"\d+", lambda x: str(shift(int(x.group(0)))), m.group(2)) + m.group(3), text)
path.write_text(text, encoding="utf-8")
print("done:", path)
