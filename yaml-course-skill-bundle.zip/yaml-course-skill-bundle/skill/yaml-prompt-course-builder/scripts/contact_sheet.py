#!/usr/bin/env python3
"""スライド画像（jpg/png）を、2列×N行のコンタクトシートにまとめる。
使い方: python3 contact_sheet.py <画像のglob> <1シートの枚数(既定4)> <出力プレフィックス>
例:     python3 contact_sheet.py "s-*.jpg" 4 sheet
"""
import sys, glob
from PIL import Image
pattern = sys.argv[1]
per = int(sys.argv[2]) if len(sys.argv) > 2 else 4
prefix = sys.argv[3] if len(sys.argv) > 3 else "sheet"
files = sorted(glob.glob(pattern))
if not files:
    sys.exit("画像が見つかりません: " + pattern)
ims = [Image.open(f) for f in files]
w, h = ims[0].size
rows = (per + 1) // 2
for n in range(0, len(ims), per):
    grp = ims[n:n + per]
    sheet = Image.new("RGB", (w * 2, h * rows), "white")
    for i, im in enumerate(grp):
        sheet.paste(im, ((i % 2) * w, (i // 2) * h))
    out = f"{prefix}{n // per + 1}.jpg"
    sheet.save(out, quality=85)
    print(out, "<-", files[n:n + per])
