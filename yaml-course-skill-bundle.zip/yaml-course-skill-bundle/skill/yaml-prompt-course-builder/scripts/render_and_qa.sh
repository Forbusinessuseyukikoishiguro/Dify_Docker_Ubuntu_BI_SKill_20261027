#!/usr/bin/env bash
# PPTXを検証 → PDF化 → 画像化 → コンタクトシート化する。
# 使い方: bash render_and_qa.sh deck.pptx [dpi=60] [1シートの枚数=4]
# 前提: /mnt/skills/public/pptx/scripts/office/{validate.py,soffice.py} が使える環境（なければパスを調整）
set -euo pipefail
DECK="$1"; DPI="${2:-60}"; PER="${3:-4}"
OFFICE=/mnt/skills/public/pptx/scripts/office
python3 "$OFFICE/validate.py" "$DECK" | tail -1
python3 "$OFFICE/soffice.py" --headless --convert-to pdf "$DECK" >/dev/null 2>&1
PDF="${DECK%.pptx}.pdf"
rm -f qa-*.jpg qasheet*.jpg
pdftoppm -jpeg -r "$DPI" "$PDF" qa
python3 "$(dirname "$0")/contact_sheet.py" "qa-*.jpg" "$PER" qasheet
echo "確認: qasheet*.jpg を開いて、はみ出し・重なり・文字化けを目視で確認する"
