#!/usr/bin/env python3
"""教材に載せるYAMLを、実際にパースして検証する。

使い方:
  python3 validate_yaml_blocks.py <ファイルまたはフォルダ> [...]

  - .md : ```yaml ... ``` ブロックをすべて取り出して検証
  - .yaml/.yml : ファイル全体を検証
  - ファイル名に "bug" を含むものは「わざと壊した例」として扱い、
    パース結果（エラー/意図と違う読まれ方）を表示するだけで失敗扱いにしない
  - .txt は対象外（スライド用の生テキスト）

終了コード: 0=すべてOK, 1=1つ以上エラー
"""
import sys, re, pathlib
try:
    import yaml
except ImportError:
    sys.exit("PyYAML が必要です: pip install pyyaml --break-system-packages")

def check(label, src, expect_broken=False):
    try:
        data = yaml.safe_load(src)
    except Exception as e:
        first = str(e).splitlines()[0]
        if expect_broken:
            print(f"  (想定どおりエラー) {label}: {type(e).__name__}: {first}")
            return True
        print(f"  NG  {label}: {type(e).__name__}: {first}")
        return False
    if expect_broken:
        print(f"  (エラーにならない: 意図と違う読まれ方かも) {label} -> {str(data)[:80]}")
    else:
        print(f"  OK  {label}")
    return True

def main(paths):
    ok = True
    files = []
    for p in map(pathlib.Path, paths):
        files += sorted(p.rglob("*")) if p.is_dir() else [p]
    for f in files:
        if f.suffix == ".md":
            text = f.read_text(encoding="utf-8")
            blocks = re.findall(r"```yaml\n(.*?)```", text, flags=re.S)
            print(f"{f} : {len(blocks)} yaml blocks")
            for i, b in enumerate(blocks, 1):
                ok &= check(f"block {i}", b)
        elif f.suffix in (".yaml", ".yml"):
            print(f)
            ok &= check(f.name, f.read_text(encoding="utf-8"), expect_broken=("bug" in f.name))
    print("RESULT:", "ALL OK" if ok else "ERRORS FOUND")
    return 0 if ok else 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    sys.exit(main(sys.argv[1:]))
