YAML×画像プロンプト講座 ビルダー（Skill＋サンプル講座）
=====================================================

■ 中身
  skill/yaml-prompt-course-builder/      Skill本体（フォルダ形式）
  skill/yaml-prompt-course-builder.skill Skill本体（パッケージ形式。同じ内容）
  sample-course/                         このSkillで作ったサンプル講座
    yaml_course_student.pptx             受講生用PPT（48枚：本編30＋ボーナス8＋特典8＋補足2）
    yaml_course_instructor.md            講師用マークダウン（台本・答え・確認テスト・短縮プラン・早見表・掲載文案）
    style_recipe_collection.yaml         特典：画風レシピ集（5レシピ＋追記枠）

■ Skillでできること
  YAML×生成AI画像プロンプトの初心者向け講座を、受講生用PPT＋講師用マークダウン＋配布YAMLの一式で作る。
  - 8ステップの「楽しい↔むずかしい」スロープ設計と、各スライドの問いかけ
  - YAML文法を「4つの箱」（行の種類／字下げ／値の書き方／使える文字）で教えるMECE構成
  - 具体と抽象・画風レシピ・採点表のボーナス／特典
  - 教材内のYAMLを実際にパースして検証するスクリプト

■ 使い方（目安）
  1. .skill ファイルを、お使いのClaude環境でスキルとして追加する（追加方法は環境により異なります）。
     フォルダ形式で使う場合は、skill/yaml-prompt-course-builder/ をスキルの置き場所にコピーする。
  2. 「YAML講座を作って。題材は〇〇、対象は文系初心者、画像は添付」のように依頼する。
  3. 手元で部品だけ使う場合：
       pip install pyyaml
       python3 skill/yaml-prompt-course-builder/scripts/validate_yaml_blocks.py <md または フォルダ>
       python3 skill/yaml-prompt-course-builder/scripts/check_yaml_behaviors.py
       cd skill/yaml-prompt-course-builder/assets && NODE_PATH=$(npm root -g) node build_deck_example.js
     （PPT生成は Node と pptxgenjs が必要）

■ 注意
  - サンプル講座の画像は、講師が生成AIで作成したものです（画像はPPT内に埋め込み済み）。
  - 3レベル・1〜5点・high/low は、人間が指示を整理するための目安で、AIの内部設定や規格ではありません。
  - 生成AIの出力は毎回変わります。同じYAMLで同じ結果になる保証はありません。
  - 特定の作家名・作品名・キャラクター名・ブランド名は、教材やレシピに入れないでください。
  - 文法ミスの挙動は PyYAML 6.0.3 での確認結果です。処理系により異なる場合があります。
