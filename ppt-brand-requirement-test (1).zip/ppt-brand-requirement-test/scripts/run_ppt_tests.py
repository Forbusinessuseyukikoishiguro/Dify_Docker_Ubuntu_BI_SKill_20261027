#!/usr/bin/env python3
"""PPTX をブランド・要件・品質の観点でテストし、結果をExcelに出力する（PPTは変更しない）。

使い方:
  python3 run_ppt_tests.py 対象.pptx --brand brand.json --requirements requirements.json --out テスト結果.xlsx

テスト一覧は reference/テスト一覧.md と対応する。
"""
import argparse
import json
import re

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.formatting.rule import CellIsRule
from openpyxl.utils import get_column_letter
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.util import Emu

F = 'Arial'
HF = PatternFill('solid', fgColor='1F3864')
thin = Side(style='thin', color='BFBFBF')
BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
PLACEHOLDER = re.compile(r'\[入力|［入力|TODO|Lorem', re.I)


def hex_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def dist(a, b):
    return sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5


def lum(rgb):
    def c(v):
        v = v / 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = rgb
    return 0.2126 * c(r) + 0.7152 * c(g) + 0.0722 * c(b)


def contrast(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True)
    return (la + 0.05) / (lb + 0.05)


def iter_shapes(shapes):
    for sh in shapes:
        if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes(sh.shapes)
        else:
            yield sh


def texts(slide):
    out = []
    for sh in iter_shapes(slide.shapes):
        if sh.has_text_frame:
            out.append(sh.text_frame.text)
    return '\n'.join(out)


def run_checks(path, brand, req):
    prs = Presentation(path)
    res = []  # (id, 区分, テスト, 対象, 期待, 結果, 実測, 修正案)

    def add(tid, cat, name, target, expect, result, measured, fix=''):
        res.append([tid, cat, name, target, expect, result, measured, fix])

    W, H = Emu(prs.slide_width).inches, Emu(prs.slide_height).inches
    ok16 = abs(W / H - 16 / 9) < 0.01
    add('P-01', '形式', 'スライドサイズが 16:9', '全体', '16:9', '合格' if ok16 else '不合格', f'{W:.2f}×{H:.2f} in', '' if ok16 else '16:9 に設定し直す')

    all_text = []
    no_title = []
    fonts_bad, colors_bad, small, contrast_bad, alt_bad, nonote, footer_miss, unknown_font = [], [], [], [], [], [], [], []
    palette = [hex_rgb(c) for c in brand.get('palette', [])]
    allowed_fonts = brand.get('fonts', [])
    min_pt = brand.get('min_body_pt')
    for idx, slide in enumerate(prs.slides, 1):
        where = f'スライド{idx}'
        tx = texts(slide)
        all_text.append(tx)
        if not tx.strip() or not any(sh.is_placeholder and sh.placeholder_format.type in (1, 3) for sh in slide.shapes):
            if not tx.strip():
                no_title.append(where)
        if brand.get('footer_text') and brand.get('check_footer') and brand['footer_text'] not in tx:
            footer_miss.append(where)
        if brand.get('check_notes') and not (slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip()):
            nonote.append(where)
        for sh in iter_shapes(slide.shapes):
            if sh.shape_type == MSO_SHAPE_TYPE.PICTURE:
                descr = sh._element.xpath('./p:nvPicPr/p:cNvPr/@descr')
                filename_like = bool(descr) and re.search(r'\.(png|jpe?g|gif|svg|bmp)$', descr[0].strip(), re.I)
                if not (descr and descr[0].strip()) or filename_like:
                    alt_bad.append(f'{where}：{sh.name}')
            # 背景色（塗り）
            bg = None
            try:
                if sh.fill.type == 1:
                    bg = hex_rgb(str(sh.fill.fore_color.rgb))
            except Exception:
                bg = None
            if bg and palette and min(dist(bg, p) for p in palette) > 16:
                colors_bad.append(f'{where}：塗り {sh.fill.fore_color.rgb}')
            if not sh.has_text_frame:
                continue
            for para in sh.text_frame.paragraphs:
                for run in para.runs:
                    if not run.text.strip():
                        continue
                    f = run.font
                    if f.name:
                        if allowed_fonts and f.name not in allowed_fonts:
                            fonts_bad.append(f'{where}：{f.name}')
                    else:
                        unknown_font.append(where)
                    if f.size is not None and min_pt and f.size.pt < min_pt:
                        small.append(f'{where}：{f.size.pt}pt「{run.text[:12]}」')
                    col = None
                    try:
                        if f.color and f.color.type is not None and f.color.rgb is not None:
                            col = hex_rgb(str(f.color.rgb))
                    except Exception:
                        col = None
                    if col and palette and min(dist(col, p) for p in palette) > 16:
                        colors_bad.append(f'{where}：文字 {f.color.rgb}')
                    if col:
                        back = bg or (255, 255, 255)
                        cr = contrast(col, back)
                        need = 4.5
                        if f.size is not None and f.size.pt >= 18:
                            need = 3.0
                        if cr < need:
                            contrast_bad.append(f'{where}：{cr:.2f}:1（基準 {need}:1）「{run.text[:12]}」')

    alltext = '\n'.join(all_text)
    add('P-02', '形式', 'タイトルのあるスライド', '全スライド', 'タイトルあり',
        '合格' if not no_title else '不合格', f'テキストなしのスライド {len(no_title)} 件', '' if not no_title else f'{", ".join(no_title)}：タイトルを入れる')
    if allowed_fonts:
        add('B-01', 'ブランド', 'フォントがブランド指定内', '全テキスト', ' / '.join(allowed_fonts),
            '不合格' if fonts_bad else ('要確認' if unknown_font else '合格'),
            (f'不一致 {len(fonts_bad)} 件：' + ', '.join(sorted(set(fonts_bad))[:5])) if fonts_bad else (f'フォント指定なし（テーマ既定）{len(unknown_font)} 件' if unknown_font else '全て指定内'),
            '指定フォントに統一' if fonts_bad else ('テーマのフォントを指定して確認' if unknown_font else ''))
    else:
        add('B-01', 'ブランド', 'フォントがブランド指定内', '全テキスト', '（基準未設定）', '要確認', 'brand.json に fonts が未設定', 'フォント基準を設定する')
    if palette:
        add('B-02', 'ブランド', '色がパレット内', '全図形', 'パレットの色（距離16以内）', '不合格' if colors_bad else '合格',
            f'逸脱 {len(colors_bad)} 件' + ('：' + '、'.join(colors_bad[:3]) if colors_bad else ''),
            '' if not colors_bad else '逸脱した色をパレットの色に置き換える')
    if min_pt:
        add('B-03', 'ブランド', f'本文の最小文字サイズ（{min_pt}pt以上）', '全テキスト', f'{min_pt}pt以上',
            '不合格' if small else '合格', f'{len(small)} 件' + ('：' + '、'.join(small[:3]) if small else ''),
            '' if not small else f'{min_pt}pt 以上に拡大')
    if brand.get('check_footer'):
        add('B-04', 'ブランド', 'フッターのブランド表記', '全スライド', brand.get('footer_text', ''), '不合格' if footer_miss else '合格',
            f'欠けているスライド {len(footer_miss)} 件', '' if not footer_miss else 'フッターを追加する')
    add('A-01', '品質', '文字と背景のコントラスト（WCAG）', '全テキスト', '4.5:1以上（大きい文字は3:1）',
        '不合格' if contrast_bad else ('要確認' if not palette and not contrast_bad and False else '合格'),
        f'不足 {len(contrast_bad)} 件' + ('：' + '、'.join(contrast_bad[:3]) if contrast_bad else ''),
        '' if not contrast_bad else '文字色を濃くする、または背景を明るくする')
    add('A-02', '品質', '画像に代替テキストがある', '全画像', '代替テキストあり',
        '不合格' if alt_bad else '合格', f'欠けている画像 {len(alt_bad)} 件', '' if not alt_bad else '画像の説明文（代替テキスト）を入れる')
    fb = [w for w in brand.get('forbidden_words', []) if w in alltext]
    add('C-01', '内容', '禁止語が含まれない', '全テキスト', '禁止語なし', '不合格' if fb else '合格',
        ('検出：' + '、'.join(fb)) if fb else '検出なし', '' if not fb else '禁止語を条件つきの表現に言い換える')
    ph = PLACEHOLDER.findall(alltext)
    add('C-02', '内容', 'プレースホルダーが残っていない', '全テキスト', '残存なし', '不合格' if ph else '合格',
        f'残存 {len(set(ph))} 種' if ph else '残存なし', '' if not ph else '未入力の箇所を埋める')
    conf = [w for w in brand.get('confidential_words', []) if w in alltext]
    if brand.get('confidential_words'):
        add('C-03', '内容', '機密語が含まれない', '全テキスト', '機密語なし', '不合格' if conf else '合格',
            ('検出：' + '、'.join(conf)) if conf else '検出なし', '' if not conf else '公開版から削除、または社内版にする')
    for kw in req.get('required_keywords', []):
        found = kw in alltext
        add('R-01', '要件', f'必須キーワード「{kw}」', '全テキスト', '含まれる', '合格' if found else '不合格',
            '含む' if found else '含まない', '' if found else f'「{kw}」を本文に入れる')
    if req.get('max_slides'):
        n = len(prs.slides)
        add('R-02', '要件', f'スライド数が{req["max_slides"]}枚以下', '全体', f'{req["max_slides"]}枚以下',
            '合格' if n <= req['max_slides'] else '不合格', f'{n} 枚', '' if n <= req['max_slides'] else '枚数を減らす')
    if brand.get('check_notes'):
        add('R-03', '要件', 'スピーカーノートがある', '全スライド', 'ノートあり', '不合格' if nonote else '合格',
            f'ノートなし {len(nonote)} 件', '' if not nonote else 'ノートを追加する')
    return res


def write(path_out, src, res):
    wb = Workbook(); wb.remove(wb.active)
    ws = wb.create_sheet('テスト結果')
    ws['A1'] = f'PPT テスト結果（{src}）'; ws['A1'].font = Font(name=F, bold=True, size=13, color='1F3864')
    heads = ['テストID', '区分', 'テスト内容', '対象', '期待（基準）', '結果', '実測・詳細', '修正案']
    for i, h in enumerate(heads, 1):
        c = ws.cell(row=3, column=i, value=h); c.font = Font(name=F, bold=True, color='FFFFFF', size=10); c.fill = HF
        c.alignment = Alignment(horizontal='center', wrap_text=True); c.border = BOX
    for r, row in enumerate(res, 4):
        for c, v in enumerate(row, 1):
            cell = ws.cell(row=r, column=c, value=v); cell.font = Font(name=F, size=10); cell.border = BOX
            cell.alignment = Alignment(wrap_text=True, vertical='top')
    last = 3 + len(res)
    for i, w in enumerate([10, 10, 30, 14, 26, 10, 44, 36], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'A4'
    ws.conditional_formatting.add(f'F4:F{last}', CellIsRule(operator='equal', formula=['"不合格"'], font=Font(name=F, color='C00000', bold=True)))
    ws.conditional_formatting.add(f'F4:F{last}', CellIsRule(operator='equal', formula=['"要確認"'], font=Font(name=F, color='C55A11', bold=True)))
    ws.conditional_formatting.add(f'F4:F{last}', CellIsRule(operator='equal', formula=['"合格"'], font=Font(name=F, color='00703C', bold=True)))

    fl = wb.create_sheet('不合格一覧')
    for i, h in enumerate(['テストID', '内容', '対象', '実測・詳細', '修正案（承認後に実施）'], 1):
        c = fl.cell(row=1, column=i, value=h); c.font = Font(name=F, bold=True, color='FFFFFF', size=10); c.fill = HF
    bad = [r for r in res if r[5] == '不合格']
    for r, row in enumerate(bad, 2):
        for c, v in enumerate([row[0], row[2], row[3], row[6], row[7]], 1):
            fl.cell(row=r, column=c, value=v).font = Font(name=F, size=10)
    for i, w in enumerate([10, 30, 14, 44, 36], 1):
        fl.column_dimensions[get_column_letter(i)].width = w

    sm = wb.create_sheet('集計', 0)
    sm['A1'] = 'テスト集計（自動）'; sm['A1'].font = Font(name=F, bold=True, size=13, color='1F3864')
    rows = [('テストの数', f"=COUNTA('テスト結果'!A4:A{last})"),
            ('合格', f"=COUNTIF('テスト結果'!F4:F{last},\"合格\")"),
            ('不合格', f"=COUNTIF('テスト結果'!F4:F{last},\"不合格\")"),
            ('要確認', f"=COUNTIF('テスト結果'!F4:F{last},\"要確認\")"),
            ('合格率（判定済みの中）', '=IFERROR(B4/(B4+B5),0)'),
            ('総合判定', '=IF(B5>0,"不合格（修正が必要）",IF(B6>0,"条件つき（要確認あり）","合格"))')]
    for i, (k, f_) in enumerate(rows, 3):
        sm.cell(row=i, column=1, value=k).font = Font(name=F, bold=True, size=10)
        sm.cell(row=i, column=2, value=f_).font = Font(name=F, size=10)
    sm['B7'].number_format = '0%'
    sm.column_dimensions['A'].width = 26; sm.column_dimensions['B'].width = 30
    sm['A11'] = '注意：テストは自動検査。要確認は人が判定する。修正は承認後に行う。'
    sm['A11'].font = Font(name=F, size=9, color='7F7F7F')
    wb.save(path_out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pptx')
    ap.add_argument('--brand', required=True)
    ap.add_argument('--requirements', default='')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    brand = json.load(open(a.brand, encoding='utf-8'))
    req = json.load(open(a.requirements, encoding='utf-8')) if a.requirements else {}
    res = run_checks(a.pptx, brand, req)
    write(a.out, a.pptx, res)
    from collections import Counter
    c = Counter(r[5] for r in res)
    print(f"テスト {len(res)} 件：合格 {c['合格']}、不合格 {c['不合格']}、要確認 {c['要確認']} → {a.out}")


if __name__ == '__main__':
    main()
