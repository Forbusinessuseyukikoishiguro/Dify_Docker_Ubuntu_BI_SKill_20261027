#!/usr/bin/env python3
"""今日の振り返りメモ（reflection.json）から、手順書・図解・明日の予定・工数差分つき進捗報告を作り、検査する。

使い方:
  python3 build_reflection.py reflection.json --out ./出力
"""
import argparse
import csv
import json
import os
import re

THRESH = 0.20


def diff_rows(tasks):
    rows = []
    for t in tasks:
        p = float(t.get('planned_h') or 0)
        a = float(t.get('actual_h')) if t.get('actual_h') not in (None, '') else None
        d = None if a is None else round(a - p, 2)
        rate = None if (a is None or p == 0) else d / p
        rows.append(dict(t, _p=p, _a=a, _d=d, _r=rate))
    return rows


def pct(r):
    return '-' if r is None else f'{r:+.0%}'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('reflection')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d = json.load(open(a.reflection, encoding='utf-8'))
    os.makedirs(a.out, exist_ok=True)
    tasks = diff_rows(d.get('tasks', []))
    warns = []
    total_p = sum(t['_p'] for t in tasks)
    total_a = sum(t['_a'] or 0 for t in tasks)
    for t in tasks:
        if t['_a'] is None:
            warns.append(('必須', t['title'], '実績工数がない'))
        if t['_r'] is not None and abs(t['_r']) >= THRESH and not t.get('reason'):
            warns.append(('必須', t['title'], f'差分 {t["_r"]:+.0%} に理由がない'))
        if t.get('reason') and '要確認' in t['reason']:
            warns.append(('推奨', t['title'], '理由が要確認のまま'))

    # 図解と学び
    mm = ['flowchart LR', f'  P["計画（予定 {total_p:g}h）"] --> E["実施（実績 {total_a:g}h）"]']
    any_big = False
    for i, t in enumerate(tasks, 1):
        big = t['_r'] is not None and abs(t['_r']) >= THRESH
        any_big = any_big or big
        mm.append(f'  E --> T{i}["{t["title"]}（{pct(t["_r"])}）"]')
        if big:
            mm.append(f'  T{i} --> R{i}["理由を見直し、見積もりに反映"]')
        else:
            mm.append(f'  T{i} --> L{i}["手順として残す"]')
    mm.append('  E --> N["明日の一手へ"]' if not any_big else '  E --> N["明日の一手へ（見積もりを修正）"]')
    rq = [f'# 振り返りと学び（{d["date"]}）', '', '## 図解', '```mermaid', '\n'.join(mm), '```', '',
          '## 工数（予定と実績）', '', '| 作業 | 予定(h) | 実績(h) | 差分(h) | 差分率 | 状態 | 理由 |', '|---|---|---|---|---|---|---|']
    for t in tasks:
        rq.append(f"| {t['title']} | {t['_p']:g} | {'' if t['_a'] is None else format(t['_a'], 'g')} | {'' if t['_d'] is None else format(t['_d'], '+g')} | {pct(t['_r'])} | {t.get('status', '')} | {t.get('reason', '') or '-'} |")
    rq += [f'| **合計** | **{total_p:g}** | **{total_a:g}** | **{total_a - total_p:+g}** | **{(total_a - total_p) / total_p:+.0%}** | | |', '', '## 学び']
    rq += [f'- {x}' for x in d.get('learnings', [])] or ['- （なし）']
    open(os.path.join(a.out, '振り返りと学び.md'), 'w', encoding='utf-8').write('\n'.join(rq) + '\n')

    # 手順書（自分用・新人向け）
    procs = d.get('procedures', [])
    me = ['# 手順チェック（自分用）', '']
    nw = ['# 手順書（新人向け）', '', '用語と期待される結果を確かめながら、一つずつ進めてください。', '']
    for p in procs:
        me += [f"## {p['title']}"] + [f"- [ ] {s['action']}" for s in p['steps']] + ['']
        nw += [f"## {p['title']}", '']
        for i, s in enumerate(p['steps'], 1):
            if not s.get('expect'):
                warns.append(('必須', p['title'], f'手順{i}に期待される結果がない'))
            nw += [f"### 手順{i}：{s['action']}", f"- 場所：{s.get('where', '要確認')}", f"- 期待される結果：{s.get('expect', '要確認')}",
                   f"- 注意：{s.get('note', 'なし')}", '']
    if not procs:
        me.append('- （手順はありません）'); nw.append('（手順はありません）')
    open(os.path.join(a.out, '手順書_自分用.md'), 'w', encoding='utf-8').write('\n'.join(me) + '\n')
    open(os.path.join(a.out, '手順書_新人向け.md'), 'w', encoding='utf-8').write('\n'.join(nw) + '\n')

    # 明日すること（高が最大三つ）
    tm = d.get('tomorrow', [])
    high = [x for x in tm if x.get('priority') == '高'][:3]
    rest = [x for x in tm if x not in high]
    tl = ['# 明日すること', '', '## 必ず（三つまで）']
    tl += [f"- [ ] {x['title']}（期限：{x.get('due') or '要確認'}／{x.get('minutes', '?')}分）" for x in high] or ['- （なし）']
    tl += ['', '## できれば']
    tl += [f"- [ ] {x['title']}（{x.get('minutes', '?')}分）" for x in rest] or ['- （なし）']
    tl += ['', '## 振り返りの問い'] + [f'{i}. {q}' for i, q in enumerate(d.get('questions', []), 1)]
    open(os.path.join(a.out, '明日すること.md'), 'w', encoding='utf-8').write('\n'.join(tl) + '\n')
    if len([x for x in tm if x.get('priority') == '高']) > 3:
        warns.append(('推奨', '明日すること', '優先度「高」が三つを超えた（どれを外すか決める）'))

    # 進捗報告（工数つき）
    pr = [f"# 進捗報告（{d['date']}）", '', f"担当：{d.get('owner', '要確認')}", '',
          f"**工数**：予定 {total_p:g}h、実績 {total_a:g}h、差分 {total_a - total_p:+g}h（{(total_a - total_p) / total_p:+.0%}）", '',
          '## 差分の説明']
    for t in tasks:
        if t['_r'] is not None and abs(t['_r']) >= THRESH:
            pr.append(f"- {t['title']}：{pct(t['_r'])}。{t.get('reason') or '理由は要確認'}")
    if not any(t['_r'] is not None and abs(t['_r']) >= THRESH for t in tasks):
        pr.append('- 大きな差分はありません（±20%以内）')
    pr += ['', '## 完了・進行中'] + [f"- {t['title']}（{t.get('status', '')}）" for t in tasks]
    pr += ['', '## 明日の予定'] + [f"- {x['title']}" for x in high + rest][:5]
    pr += ['', '## 判断が必要な事項', '- （本人が記入）']
    open(os.path.join(a.out, '進捗報告.md'), 'w', encoding='utf-8').write('\n'.join(pr) + '\n')

    # 工数CSV
    with open(os.path.join(a.out, '工数.csv'), 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['日付', '作業', '予定(h)', '実績(h)', '差分(h)=実績-予定', '差分率', '状態', '理由'])
        for t in tasks:
            w.writerow([d['date'], t['title'], t['_p'], '' if t['_a'] is None else t['_a'], '' if t['_d'] is None else t['_d'], '' if t['_r'] is None else f"{t['_r']:.0%}", t.get('status', ''), t.get('reason', '')])

    ck = ['# 検査結果', '']
    ck += ['| 判定 | 対象 | 指摘 |', '|---|---|---|'] + [f'| {l} | {w_} | {m} |' for l, w_, m in warns] if warns else ['指摘なし（自動検査の範囲で）']
    open(os.path.join(a.out, '検査結果.md'), 'w', encoding='utf-8').write('\n'.join(ck) + '\n')
    must = sum(1 for x in warns if x[0] == '必須')
    print(f'wrote {a.out}（工数差分 {total_a - total_p:+g}h、指摘 {len(warns)} 件、必須 {must} 件）')


if __name__ == '__main__':
    main()
