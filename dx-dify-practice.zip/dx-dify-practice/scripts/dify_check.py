#!/usr/bin/env python3
"""Dify の起動状態を確認する（読み取り専用）。

使い方:
  python3 dify_check.py --compose-dir ./dify/docker --url http://localhost
"""
import argparse
import subprocess
import urllib.error
import urllib.request


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--compose-dir', required=True)
    ap.add_argument('--url', default='http://localhost')
    a = ap.parse_args()
    try:
        out = subprocess.run(['docker', 'compose', 'ps', '--format', '{{.Service}} {{.State}}'],
                             cwd=a.compose_dir, capture_output=True, text=True, timeout=60)
        lines = [l for l in out.stdout.splitlines() if l.strip()]
        bad = [l for l in lines if 'running' not in l.lower()]
        print(f'サービス数：{len(lines)}、running 以外：{len(bad)}')
        for l in bad:
            print('  要確認：', l)
        if out.returncode != 0:
            print('docker compose の実行に失敗：', out.stderr.strip()[:200])
    except FileNotFoundError:
        print('docker が見つかりません')
    except Exception as e:
        print('compose の確認に失敗：', e.__class__.__name__)
    for path in ['/install', '/v1']:
        try:
            req = urllib.request.Request(a.url + path, method='HEAD')
            with urllib.request.urlopen(req, timeout=10) as res:
                print(f'{path}: HTTP {res.status}')
        except urllib.error.HTTPError as e:
            print(f'{path}: HTTP {e.code}（応答あり）')
        except Exception as e:
            print(f'{path}: 応答なし（{e.__class__.__name__}）')


if __name__ == '__main__':
    main()
