#!/usr/bin/env python3
"""ダッシュボードのHTMLを検査する（読み取り専用）。構造・アクセシビリティ・外部依存の基本チェック。

使い方:
  python3 check_dashboard.py 画面.html
"""
import re
import sys
from html.parser import HTMLParser

VOID = {'meta', 'link', 'img', 'input', 'br', 'hr', 'source', 'area', 'col', 'embed', 'track', 'wbr'}


class Checker(HTMLParser):
    def __init__(self):
        super().__init__()
        self.stack, self.problems = [], []
        self.ids = []
        self.imgs_without_alt = 0
        self.has_lang = False
        self.has_viewport = False
        self.external = []
        self.tables = 0
        self.table_has_th = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'html' and a.get('lang'):
            self.has_lang = True
        if tag == 'meta' and a.get('name') == 'viewport':
            self.has_viewport = True
        if tag == 'img' and not a.get('alt') and a.get('alt') is None:
            self.imgs_without_alt += 1
        if tag in ('script', 'link') and (a.get('src', '') or a.get('href', '')).startswith('http'):
            self.external.append(a.get('src') or a.get('href'))
        if 'id' in a:
            self.ids.append(a['id'])
        if tag == 'table':
            self.tables += 1
        if tag == 'th':
            self.table_has_th += 1
        if tag not in VOID:
            self.stack.append((tag, self.getpos()[0]))

    def handle_endtag(self, tag):
        if tag in VOID:
            return
        if self.stack and self.stack[-1][0] == tag:
            self.stack.pop()
        else:
            self.problems.append(f'閉じタグの対応が崩れています：</{tag}>（{self.getpos()[0]}行目付近）')
            for i in range(len(self.stack) - 1, -1, -1):
                if self.stack[i][0] == tag:
                    del self.stack[i:]
                    break


def main():
    text = open(sys.argv[1], encoding='utf-8').read()
    c = Checker()
    c.feed(text)
    probs = list(c.problems)
    if c.stack:
        probs.append('閉じられていないタグ：' + ', '.join(t for t, _ in c.stack[:5]))
    if not c.has_lang:
        probs.append('html 要素に lang（例：ja）がありません（読み上げに必要）')
    if not c.has_viewport:
        probs.append('viewport の指定がありません（スマホで縮小表示になる）')
    if c.imgs_without_alt:
        probs.append(f'alt のない img が {c.imgs_without_alt} 件')
    if c.external:
        probs.append('外部のファイルを読み込んでいます（社外通信が必要になる）：' + ', '.join(c.external[:3]))
    dup = sorted({i for i in c.ids if c.ids.count(i) > 1})
    if dup:
        probs.append('id が重複しています：' + ', '.join(dup))
    if 'aria-label' not in text and 'aria-labelledby' not in text:
        probs.append('セクションの名前（aria-label など）がありません（任意だが推奨）')
    if re.search(r'color:\s*#(?:[0-9a-fA-F]{3}){1,2}\b', text) and 'prefers-color-scheme' not in text:
        probs.append('配色の切り替え（ダークモード）が未対応（任意）')
    if c.tables and c.table_has_th == 0:
        probs.append('表にヘッダー（th）がありません')
    print('問題なし' if not probs else f'{len(probs)} 件の要確認：')
    for p in probs:
        print('- ' + p)
    return 1 if probs else 0


if __name__ == '__main__':
    sys.exit(main())
