#!/usr/bin/env python3
"""業務要件（business.json）から、Mermaid 図、ToDo（CSV）、Notion・Slack・メモ用の文書、検査結果を作る。

使い方:
  python3 build_diagram_todo.py business.json --out ./出力
"""
import argparse
import csv
import json
import os
import re

ID_OK = re.compile(r'^[A-Za-z][A-Za-z0-9_]*$')


def q(text):
    """Mermaid のラベルを安全に引用する。"""
    return '"' + text.replace('"', "'") + '"'


def flow(d, warns):
    steps = {s['id']: s for s in d['steps']}
    lines = ['flowchart TD']
    ids = set()
    for s in d['steps']:
        if s['id'] in ids:
            warns.append(('必須', 'M-01', s['id'], 'ノードIDが重複'))
        ids.add(s['id'])
        if not ID_OK.match(s['id']):
            warns.append(('必須', 'M-01', s['id'], 'IDは英字で始まる英数字にする'))
    actors = []
    for s in d['steps']:
        if s.get('actor') not in actors:
            actors.append(s.get('actor'))
    for k, a in enumerate(actors, 1):
        sid = f'G{k}'
        lines.append(f'  subgraph {sid}[{q(a)}]')
        for s in d['steps']:
            if s.get('actor') != a:
                continue
            if s.get('type') == 'decision':
                lines.append(f'    {s["id"]}{{{q(s["text"])}}}')
            else:
                lines.append(f'    {s["id"]}[{q(s["text"])}]')
        lines.append('  end')
    for s in d['steps']:
        if s.get('type') == 'decision':
            for label, key in [('はい', 'yes'), ('いいえ', 'no')]:
                t = s.get(key)
                if not t:
                    warns.append(('必須', 'M-02', s['id'], f'判断に「{label}」の枝がない'))
                    continue
                if t != 'END' and t not in ids:
                    warns.append(('必須', 'M-03', s['id'], f'行き先 {t} が存在しない'))
                lines.append(f'  {s["id"]} -- {q(label)} --> {t if t != "END" else "END_NODE((終了))"}')
        else:
            t = s.get('next')
            if t is None:
                warns.append(('推奨', 'M-05', s['id'], '次の工程が書かれていない（終了なら END）'))
                continue
            if t != 'END' and t not in ids:
                warns.append(('必須', 'M-03', s['id'], f'行き先 {t} が存在しない'))
            lines.append(f'  {s["id"]} --> {t if t != "END" else "END_NODE((終了))"}')
    for s in d['steps']:
        if re.search(r'[（()）:：,，/]', s['text']) and s.get('type') != 'decision':
            pass
    return '\n'.join(lines) + '\n'


def states(d, warns):
    lines = ['stateDiagram-v2']
    names = {s['name'] for s in d.get('states', [])}
    ids = {n: f'ST{k}' for k, n in enumerate(sorted(names), 1)}
    for n, i in ids.items():
        lines.append(f'  state {q(n)} as {i}')
    for s in d.get('states', []):
        for t in s.get('to', []):
            if t not in names:
                warns.append(('必須', 'M-03', s['name'], f'遷移先 {t} が状態にない'))
                continue
            lines.append(f'  {ids[s["name"]]} --> {ids[t]}')
    if d.get('states'):
        first = d['states'][0]['name']
        lines.insert(1, f'  [*] --> {ids[first]}')
    return '\n'.join(lines) + '\n'


def sequence(d):
    lines = ['sequenceDiagram']
    ids = {a: f'P{k}' for k, a in enumerate(d.get('actors', []), 1)}
    for a, i in ids.items():
        lines.append(f'  participant {i} as {a}')
    for it in d.get('interactions', []):
        lines.append(f'  {ids[it["from"]]}->>{ids[it["to"]]}: {it["msg"]}')
    return '\n'.join(lines) + '\n'


def todo_rows(d):
    rows = []
    prev = None
    for n, s in enumerate(d['steps'], 1):
        kind = '判断' if s.get('type') == 'decision' else '工程'
        rid = f'T-{n:02d}'
        deps = prev or '-'
        rows.append([rid, kind, s['text'], s.get('actor', d.get('todo_owner_default', '担当（役割）')), deps, '未着手', '完了条件：' + (f"「{s['text']}」が完了し、次の工程へ進む" if kind == '工程' else '判断の結果が記録されている'), d.get('due', '要確認')])
        prev = rid
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('business')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d = json.load(open(a.business, encoding='utf-8'))
    os.makedirs(a.out, exist_ok=True)
    warns = []
    f = flow(d, warns); st = states(d, warns); sq = sequence(d)
    open(os.path.join(a.out, '業務フロー.mmd'), 'w', encoding='utf-8').write(f)
    open(os.path.join(a.out, '状態遷移.mmd'), 'w', encoding='utf-8').write(st)
    open(os.path.join(a.out, 'シーケンス.mmd'), 'w', encoding='utf-8').write(sq)
    open(os.path.join(a.out, '業務フロー.md'), 'w', encoding='utf-8').write(f'# {d["title"]}（業務フロー）\n\n```mermaid\n{f}```\n')
    rows = todo_rows(d)
    with open(os.path.join(a.out, 'ToDo.csv'), 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['ID', '種別', 'ToDo', '担当（役割）', '前の工程', '状態', '完了条件', '期限'])
        w.writerows(rows)
    notion = [f'# {d["title"]}', '', '## フロー図', '```mermaid', f.rstrip(), '```', '', '## ToDo', '| ID | ToDo | 担当 | 前の工程 | 状態 |', '|---|---|---|---|---|']
    notion += [f'| {r[0]} | {r[2]} | {r[3]} | {r[4]} | {r[5]} |' for r in rows]
    open(os.path.join(a.out, 'notion.md'), 'w', encoding='utf-8').write('\n'.join(notion) + '\n')
    slack = [f'【{d["title"]}】業務フローとToDoを共有します。', f'ToDo：{len(rows)} 件（判断 {sum(1 for r in rows if r[1] == "判断")} 件）。',
             '未決事項：' + ('、'.join(s['text'] for s in d['steps'] if '要確認' in s['text']) or 'なし'),
             '次の一手：' + rows[0][2] + f'（担当：{rows[0][3]}）']
    open(os.path.join(a.out, 'slack.txt'), 'w', encoding='utf-8').write('\n'.join(slack) + '\n')
    memo = [f'# {d["title"]}（作業メモ）', ''] + [f'- {r[0]} {r[2]}（{r[1]}／{r[3]}）' for r in rows]
    open(os.path.join(a.out, 'メモ.md'), 'w', encoding='utf-8').write('\n'.join(memo) + '\n')
    chk = ['# 検査結果', '']
    chk += ['| 判定 | ID | 場所 | 指摘 |', '|---|---|---|---|'] + [f'| {l} | {c} | {w} | {m} |' for l, c, w, m in warns] if warns else ['指摘なし（自動検査の範囲で）']
    open(os.path.join(a.out, '検査結果.md'), 'w', encoding='utf-8').write('\n'.join(chk) + '\n')
    must = sum(1 for x in warns if x[0] == '必須')
    print(f'wrote {a.out}（ToDo {len(rows)} 件、指摘 {len(warns)} 件、必須 {must} 件）')


if __name__ == '__main__':
    main()
