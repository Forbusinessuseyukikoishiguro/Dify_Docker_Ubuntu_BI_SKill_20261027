// Mermaid の構文を検証する（描画はしない）。.mmd は全体を、.md は ```mermaid のブロックを検査する。
// 事前準備：  cd scripts && npm install   （mermaid と jsdom を入れる）
// 使い方：    node mermaid_check.mjs 図.mmd 業務フロー.md
// 終了コード：0＝すべて OK、1＝構文エラーあり
import { JSDOM } from 'jsdom';
import fs from 'fs';
import path from 'path';

const dom = new JSDOM('<!doctype html><html><body></body></html>', { pretendToBeVisual: true });
globalThis.window = dom.window;
globalThis.document = dom.window.document;
globalThis.DOMParser = dom.window.DOMParser;
globalThis.Element = dom.window.Element;
globalThis.HTMLElement = dom.window.HTMLElement;
globalThis.SVGElement = dom.window.SVGElement || dom.window.Element;
const { default: mermaid } = await import('mermaid');
mermaid.initialize({ startOnLoad: false });

function blocksOf(file, text) {
  if (file.endsWith('.md')) {
    const out = [];
    const re = /```mermaid\n([\s\S]*?)```/g;
    let m, n = 0;
    while ((m = re.exec(text))) { n += 1; out.push({ label: `${file} 図${n}`, code: m[1] }); }
    return out;
  }
  return [{ label: file, code: text }];
}

let ng = 0, total = 0;
for (const file of process.argv.slice(2)) {
  const text = fs.readFileSync(file, 'utf8');
  for (const b of blocksOf(file, text)) {
    total += 1;
    try {
      const r = await mermaid.parse(b.code);
      console.log(`OK  ${b.label}（${r.diagramType}）`);
    } catch (e) {
      ng += 1;
      const msg = String(e.message || e).split('\n').filter(Boolean).slice(0, 2).join(' / ');
      console.log(`NG  ${b.label}：${msg}`);
    }
  }
}
console.log(`検査 ${total} 件、構文エラー ${ng} 件`);
process.exitCode = ng ? 1 : 0;
