#!/usr/bin/env python3
"""開発ドキュメントのひな形（Excel・Googleスプレッドシート用CSV・Notion用Markdown）を作る。

使い方:
  python3 build_templates.py --out ./出力 --domain 金融

- Excel：全シート。網羅性シートは数式で自動集計する。
- gsheets/：各シートのCSV（Googleスプレッドシートの「インポート」で取り込める。UTF-8 BOM付き）
- notion/：Notionに貼り付けるMarkdownのひな形
- サンプル行は架空。実案件の基準（規程・監督指針・委託元の要件）に置き換えること。
"""
import argparse
import csv
import os

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

F = 'Arial'
HF = PatternFill('solid', fgColor='1F3864')
SUB = PatternFill('solid', fgColor='D9E2F3')
INP = PatternFill('solid', fgColor='FFF2CC')
thin = Side(style='thin', color='BFBFBF')
BOX = Border(left=thin, right=thin, top=thin, bottom=thin)

SHEETS = {
    '要件定義': dict(
        headers=['要件ID', '区分', '要件名', '要件の内容', '優先度', '根拠・出典', '受け入れ基準', '状態'],
        widths=[10, 10, 26, 44, 10, 26, 40, 10],
        rows=[
            ['REQ-001', '機能', '振込上限額の制御', '1回の振込依頼が上限額を超える場合、依頼を受け付けず理由を表示する', 'Must', '社内規程（仮・要確認）', '上限ちょうどは受付、上限超過は拒否。拒否理由が画面に表示される', '草案'],
            ['REQ-002', '機能', 'ログイン時の二段階認証', 'ログイン時に、登録済みの端末で確認コードを入力させる', 'Must', '社内セキュリティ方針（仮）', '正しいコードでのみログインできる。誤りで再入力になる', '草案'],
            ['REQ-003', '機能', '残高不足時の表示', '残高が振込金額に満たない時、振込を止めて残高不足を表示する', 'Must', '業務要件（仮）', '残高不足の時は実行されず、エラーが表示される', '草案'],
            ['REQ-004', '非機能', 'ログイン失敗時のロック', '連続したログイン失敗が一定回数を超えたら、アカウントを一時的にロックする', 'Must', 'セキュリティ要件（回数は要確認）', 'ロック後は正しいパスワードでもログインできず、解除手順が案内される', '草案'],
            ['REQ-005', '非機能', '稼働率（営業時間中）', '営業時間中の稼働率の目標を定める', 'Should', '委託元の要件（目標値は要確認）', '目標値が決まり、測定方法が定義されている', '草案'],
        ]),
    '詳細設計': dict(
        headers=['設計ID', '要件ID', '機能名', '入力', '処理', '出力', '例外・エラー', '備考'],
        widths=[10, 10, 24, 30, 40, 30, 36, 16],
        rows=[
            ['DSG-001', 'REQ-001', '振込上限チェック', '振込金額、口座区分', '口座区分ごとの上限と比較し、超過なら拒否', '受付可否、拒否理由', 'E-101：上限超過', ''],
            ['DSG-002', 'REQ-002', '確認コード照合', 'ユーザーID、入力コード', '登録端末の発行コードと照合し、一致で認証', '認証結果', 'E-201：コード不一致（再入力）', ''],
            ['DSG-003', 'REQ-003', '残高チェック', '口座残高、振込金額', '残高 ≧ 金額 を確認', '実行可否', 'E-301：残高不足', ''],
            ['DSG-004', 'REQ-004', 'ログイン失敗カウント', 'ユーザーID、認証結果', '連続失敗を数え、閾値超えでロック', 'ロック状態', 'E-401：ロック中', '閾値は要確認'],
        ]),
    '実装仕様': dict(
        headers=['仕様ID', '設計ID', '対象（API・画面・バッチ）', '仕様（項目・型・制約）', 'エラーコード', '実装メモ'],
        widths=[10, 10, 26, 46, 14, 36],
        rows=[
            ['IMP-001', 'DSG-001', 'API：POST /transfers', 'amount：整数、1以上。上限は設定値から取得', 'E-101', '上限値は設定ファイルで管理（コードに直書きしない）'],
            ['IMP-002', 'DSG-003', 'API：POST /transfers', '残高照会は同一トランザクション内で行う', 'E-301', ''],
        ]),
    'テスト計画': dict(
        headers=['観点', '対象範囲', '方針', '環境', '完了基準', '責任者'],
        widths=[12, 30, 40, 22, 36, 12],
        rows=[
            ['機能', '要件のすべて', '正常系、境界値、異常系を要件ごとに作る', 'テスト環境（本番データ不可）', '必須要件の網羅率100%、不具合の未解決0件', '（記入）'],
            ['境界値', '金額・回数の上限', '上限ちょうど、上限+1、0、負数を確認', 'テスト環境', '全境界値ケースが合格', '（記入）'],
            ['異常系', '入力誤り、残高不足、認証失敗', '表示されるエラーとログを確認', 'テスト環境', '全異常系ケースが合格', '（記入）'],
            ['性能', '営業時間の想定負荷', '目標値は要件で定める（要確認）', '性能検証環境', '目標値を満たす', '（記入）'],
            ['セキュリティ', 'ログイン、ロック、認証', '失敗時の挙動と、情報の露出を確認', 'テスト環境', '指摘の重大度が「高」で未解決0件', '（記入）'],
        ]),
    'テストケース': dict(
        headers=['TC-ID', '要件ID', '観点', '前提', '手順', '期待結果', '実施結果', '担当', '備考'],
        widths=[10, 10, 10, 26, 40, 36, 12, 10, 20],
        rows=[
            ['TC-001', 'REQ-001', '境界値', '口座区分A、上限=100,000円', '100,000円で振込を依頼する', '受付される', '未実施', '（記入）', ''],
            ['TC-002', 'REQ-001', '異常系', '口座区分A、上限=100,000円', '100,001円で振込を依頼する', '拒否され、理由が表示される', '未実施', '（記入）', ''],
            ['TC-003', 'REQ-002', '正常系', '端末にコードが届いている', '正しいコードを入力する', 'ログインできる', '未実施', '（記入）', ''],
            ['TC-004', 'REQ-002', '異常系', '端末にコードが届いている', '誤ったコードを入力する', '再入力になり、ログインできない', '未実施', '（記入）', ''],
            ['TC-005', 'REQ-003', '異常系', '残高が振込額より少ない', '振込を実行する', '実行されず、残高不足が表示される', '未実施', '（記入）', ''],
            ['TC-006', 'REQ-004', '異常系', 'アカウントが有効', '閾値を超えて失敗する', 'ロックされ、解除の案内が出る', '未実施', '（記入）', ''],
            # REQ-005 は意図的にテストケースを空けてある（網羅性の確認用）
        ]),
    '網羅性': dict(headers=None, widths=[12, 28, 12, 14, 12, 14, 30], rows=None),
    'お客様手順': dict(
        headers=['手順No', '操作内容', '画面・場所', '期待される表示', '注意事項', '困った時'],
        widths=[10, 40, 24, 30, 30, 30],
        rows=[
            ['1', 'ログイン画面でユーザーIDとパスワードを入力し、「ログイン」を押す', 'ログイン画面', '確認コードの入力画面が表示される', '※ 画面の版：〇〇（確認日：〇〇）', 'ロックされた場合は、案内窓口へ（連絡先：〇〇）'],
            ['2', '登録端末に届いた確認コードを入力し、「確定」を押す', '確認コード画面', 'トップ画面が表示される', 'コードの有効期限は〇分（要確認）', '届かない場合は再送してください'],
        ]),
    '社内資料チェック': dict(
        headers=['項目', '内容', '出典・根拠', '最終更新日', '確認者', '判定（○／×）'],
        widths=[22, 44, 30, 14, 12, 14],
        rows=[
            ['版数・確認日', '資料の版数と確認日を記載している', '社内ルール（要確認）', '', '', ''],
            ['用語の統一', '同じ概念に同じ用語を使っている', '社内用語集（要確認）', '', '', ''],
            ['根拠の明記', '規格・ガイドラインは確認済みのものを使い、出典を書いている', 'reference/根拠一覧.md', '', '', ''],
            ['未確認の明記', '未確認の数値・規格は、本文でなく「要確認」と書いている', '', '', '', ''],
        ]),
}


import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))


def header_row(ws, row, headers):
    for i, h in enumerate(headers, 1):
        c = ws.cell(row=row, column=i, value=h)
        c.font = Font(name=F, bold=True, color='FFFFFF', size=10)
        c.fill = HF
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        c.border = BOX


def build_excel(path, domain):
    wb = Workbook()
    cover = wb.active
    cover.title = '表紙'
    cover['A1'] = '開発ドキュメント（ひな形）'
    cover['A1'].font = Font(name=F, bold=True, size=16, color='1F3864')
    lines = [
        f'業界：{domain}（サンプルの数値・名称は架空）',
        '対象システム：［入力］　　版：［入力］　　確認日：［入力］',
        '',
        '根拠：ISO/IEC/IEEE 29148:2018（確認済み）、デジタル社会推進標準ガイドライン群（確認済み）',
        '※ 規格は適用の指針であり、認証の対象ではない。未確認の規格は本文で引用しない。',
        '',
        'シート：要件定義 → 詳細設計 → 実装仕様 → テスト計画 → テストケース → 網羅性（自動集計） → お客様手順 → 社内資料チェック',
        '黄色のセルに入力する。網羅性シートは数式のため入力不要。',
    ]
    for i, t in enumerate(lines, 3):
        cover.cell(row=i, column=1, value=t).font = Font(name=F, size=10)
    cover.column_dimensions['A'].width = 110

    for name, spec in SHEETS.items():
        if name == '網羅性':
            continue
        ws = wb.create_sheet(name)
        header_row(ws, 1, spec['headers'])
        for r_i, row in enumerate(spec['rows'], 2):
            for c_i, v in enumerate(row, 1):
                cell = ws.cell(row=r_i, column=c_i, value=v)
                cell.font = Font(name=F, size=10)
                cell.alignment = Alignment(wrap_text=True, vertical='top')
                cell.border = BOX
        for r_i in range(len(spec['rows']) + 2, len(spec['rows']) + 40):
            for c_i in range(1, len(spec['headers']) + 1):
                ws.cell(row=r_i, column=c_i).fill = INP
                ws.cell(row=r_i, column=c_i).border = BOX
        for i, w in enumerate(spec['widths'], 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.freeze_panes = 'A2'

    # 網羅性（数式）
    ws = wb.create_sheet('網羅性', index=wb.sheetnames.index('テストケース') + 1)
    ws['A1'] = '網羅性チェック（要件 → 設計 → テストの追跡）'
    ws['A1'].font = Font(name=F, bold=True, size=12, color='1F3864')
    headers = ['要件ID', '要件名', '設計件数', 'テスト件数', '異常系の件数', '網羅判定', '異常系判定', '優先度']
    header_row(ws, 3, headers)
    req = SHEETS['要件定義']['rows']
    n = len(req)
    for i, row in enumerate(req):
        r = 4 + i
        ws.cell(row=r, column=1, value=f"='要件定義'!A{2 + i}")
        ws.cell(row=r, column=2, value=f"='要件定義'!C{2 + i}")
        ws.cell(row=r, column=3, value=f"=COUNTIF('詳細設計'!B:B,A{r})")
        ws.cell(row=r, column=4, value=f"=COUNTIF('テストケース'!B:B,A{r})")
        ws.cell(row=r, column=5, value=f"=COUNTIFS('テストケース'!B:B,A{r},'テストケース'!C:C,\"異常系\")")
        ws.cell(row=r, column=6, value=f'=IF(D{r}>0,"○","×")')
        ws.cell(row=r, column=7, value=f'=IF(\'要件定義\'!B{2 + i}="機能",IF(E{r}>0,"○","要追加"),"対象外")')
        ws.cell(row=r, column=8, value=f"='要件定義'!E{2 + i}")
        for c in range(1, 9):
            cell = ws.cell(row=r, column=c)
            cell.font = Font(name=F, size=10)
            cell.border = BOX
            cell.alignment = Alignment(vertical='top', wrap_text=True, horizontal='center' if c != 2 else 'left')
    last = 3 + n
    s = last + 2
    summary = [
        ('要件数', f'=COUNTA(A4:A{last})'),
        ('テストがある要件数', f'=COUNTIF(F4:F{last},"○")'),
        ('網羅率', f'=IFERROR(B{s + 1}/B{s},0)'),
        ('必須（Must）の網羅率', f'=IFERROR(COUNTIFS(H4:H{last},"Must",F4:F{last},"○")/COUNTIF(H4:H{last},"Must"),0)'),
        ('異常系が要追加の機能要件数', f'=COUNTIF(G4:G{last},"要追加")'),
        ('リリース判定（自動）', f'=IF(AND(B{s + 2}=1,B{s + 3}=1,B{s + 4}=0),"進めてよい（確認要）","保留")'),
    ]
    for i, (k, f_) in enumerate(summary):
        ws.cell(row=s + i, column=1, value=k).font = Font(name=F, bold=True, size=10)
        c = ws.cell(row=s + i, column=2, value=f_)
        c.font = Font(name=F, size=10)
    ws.cell(row=s + 2, column=2).number_format = '0%'
    ws.cell(row=s + 3, column=2).number_format = '0%'
    ws.cell(row=s + 7, column=1, value='判定の基準：reference/網羅性の考え方.md。判定は人が確認する。').font = Font(name=F, size=9, color='7F7F7F')
    for i, w in enumerate([12, 28, 12, 12, 14, 12, 14, 10], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    wb.save(path)


def build_csv(folder):
    os.makedirs(folder, exist_ok=True)
    for name, spec in SHEETS.items():
        if name == '網羅性':
            continue
        with open(os.path.join(folder, f'{name}.csv'), 'w', encoding='utf-8-sig', newline='') as f:
            w = csv.writer(f)
            w.writerow(spec['headers'])
            w.writerows(spec['rows'])


NOTION = {
    '要件定義書': ['## 1. 目的と背景', '## 2. 対象範囲', '## 3. 要件一覧', '（表：要件ID／区分／要件名／内容／優先度／根拠／受け入れ基準）', '## 4. 非機能要件（目標値は要確認）', '## 5. 未確認事項'],
    '詳細設計書': ['## 1. 対象要件', '## 2. 機能の概要', '## 3. 入力・処理・出力', '## 4. 例外・エラー', '## 5. 要件との対応（REQ → DSG）'],
    '実装仕様書': ['## 1. 対象API・画面', '## 2. 項目仕様（項目・型・制約）', '## 3. エラーコード一覧', '## 4. 設定値（コードに直書きしない）'],
    'テスト計画書': ['## 1. 目的・範囲', '## 2. 観点と方針', '## 3. 環境', '## 4. 完了基準', '## 5. リスクと未確認事項'],
    'お客様手順書': ['## 1. 対象と前提（画面の版・確認日）', '## 2. 手順', '（手順ごとに：操作／表示／注意／困った時）', '## 3. よくある質問', '## 4. 問い合わせ先（要確認）'],
    '社内資料': ['## 1. 目的', '## 2. 内容', '## 3. 根拠（確認済みの規格・ガイドラインのみ）', '## 4. 未確認事項（要確認）', '## 5. 更新履歴'],
}


def build_notion(folder):
    os.makedirs(folder, exist_ok=True)
    for name, sections in NOTION.items():
        lines = [f'# {name}（ひな形）', '', '| プロパティ | 値 |', '|---|---|', '| 版数 | [入力] |', '| 確認日 | [入力] |', '| 担当 | [入力] |', '| 状態 | 草案 |', '']
        lines += sections
        lines += ['', '---', '※ Notionでは、この内容を貼り付け、表はデータベース（CSV読み込み）に移すと、要件とテストの対応を一覧で管理できる。']
        open(os.path.join(folder, f'{name}.md'), 'w', encoding='utf-8').write('\n'.join(lines) + '\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--domain', default='金融')
    ap.add_argument('--profile', default='default', choices=['default', 'insurance'])
    a = ap.parse_args()
    if a.profile == 'insurance':
        import profile_insurance
        SHEETS.clear(); SHEETS.update(profile_insurance.SHEETS)
        a.domain = '保険'
    os.makedirs(a.out, exist_ok=True)
    build_excel(os.path.join(a.out, 'ひな形.xlsx'), a.domain)
    build_csv(os.path.join(a.out, 'gsheets'))
    build_notion(os.path.join(a.out, 'notion'))
    print('wrote', a.out)


if __name__ == '__main__':
    main()
