#!/usr/bin/env python3
"""エラーログを分類し、仮説・確かめ方・根拠（論文・公式）を含む分析レポートを作る（読み取り専用）。

使い方:
  python3 scripts/analyze_error.py エラーログ.txt --out 分析.md

- Node.js（JavaScript）と Python（Traceback）の両方に対応。
- 発生箇所は、Node.js は最初の行、Python は最後の File 行（最も内側）から取る。
- 判定は仮説。確定は再現と確認で行う。
"""
import argparse
import re

RULES = [
    # (id, 正規表現, 種類, 発生層, 仮説, 確かめ方, 言語)
    ('PY_IMPORT', r'ModuleNotFoundError|ImportError', '依存関係', '依存関係・実行環境', '未インストール、または別の Python（仮想環境の違い）を使っている', 'sys.executable を表示し、pip show で確認', 'py'),
    ('PY_NONE', r"'NoneType' object|NoneType", '型・値', 'コード・データ', '戻り値が None（return 漏れ、または取得失敗）', '直前の戻り値を repr で出力', 'py'),
    ('PY_KEY', r'KeyError', 'データ', 'コード・データ', '辞書に無いキーを参照した', 'キーの一覧を出力、または dict.get を検討', 'py'),
    ('PY_INDEX', r'IndexError', 'データ', 'コード・データ', '範囲外のインデックス', 'len() を出力して境界を確認', 'py'),
    ('PY_VALUE', r'ValueError', '型・値', 'コード・データ', '値の形式が想定と違う', '入力の生の値を repr で出力', 'py'),
    ('PY_ZERO', r'ZeroDivisionError', '型・値', 'コード', '除数が 0', '除数の値を確認', 'py'),
    ('PY_NAME', r'NameError', '参照', 'コード', '変数の綴り違い、または定義より前に使用', '定義行と綴りを確認', 'py'),
    ('PY_ATTR', r'AttributeError', '型・値', 'コード', 'オブジェクトに無い属性、または None への属性参照', '型を type() で出力', 'py'),
    ('PY_TYPE', r'TypeError', '型・値', 'コード', '引数の数・型が関数の定義と違う', '関数のシグネチャと呼び出しを比べる', 'py'),
    ('PY_RECURSION', r'RecursionError', '制御', 'コード', '再帰の終了条件がない', '終了条件と引数の変化を確認', 'py'),
    ('PY_JSON', r'JSONDecodeError', 'データ', 'データ・外部サービス', '応答が JSON ではない（HTMLのエラーページ等）', '応答の先頭を repr で出力', 'py'),
    ('PY_UNICODE', r'UnicodeDecodeError|UnicodeEncodeError', 'データ', 'データ', '文字コードの指定が違う', 'open() の encoding を明示', 'py'),
    ('PY_FNF', r'FileNotFoundError', 'ファイル', 'OS・設定', 'ファイルがない、またはカレントフォルダが違う', 'os.getcwd() と絶対パスを出力', 'py'),
    ('PY_PERM', r'PermissionError', '権限', 'OS', '実行者に権限がない', 'ls -l で所有者と権限を確認', 'py'),
    ('JS_MODULE', r'Cannot find module', '依存関係', '依存関係・実行環境', 'パッケージが未インストール、またはパスが違う', 'npm ls で確認。実行中の環境を確認', 'js'),
    ('JS_SYNTAX', r'SyntaxError|Unexpected token', '構文', 'コード', '括弧・引用符・カンマの欠落', 'エラー行の前後を表示して確認', 'js'),
    ('JS_REF', r'ReferenceError|is not defined', '参照', 'コード', '綴り違い、宣言忘れ、スコープ外', '宣言の場所と綴りを検索', 'js'),
    ('JS_TYPE_NULL', r'Cannot read propert(y|ies) of (undefined|null)', '型・値', 'コード・データ', '値が undefined/null のまま使われた', '直前の値を出力し、無い理由を確認', 'js'),
    ('JS_TYPE', r'is not a function', '型・値', 'コード', '関数ではない値を呼んだ', '型を typeof で出力', 'js'),
    ('ENOENT', r'ENOENT|No such file or directory', 'ファイル', 'OS・設定', 'ファイルの場所が違う（カレントフォルダ）', '絶対パスを表示し、存在を確認', 'any'),
    ('EACCES', r'EACCES|Permission denied', '権限', 'OS', '実行者に権限がない', 'ls -l で所有者と権限を確認', 'any'),
    ('EADDR', r'EADDRINUSE|address already in use', 'ポート', 'OS', '同じポートを別のプロセスが使用中', 'ss -ltnp で使用中のプロセスを確認', 'any'),
    ('ECONN', r'ECONNREFUSED|Connection refused', 'ネットワーク', '外部サービス・ネットワーク', '接続先が停止、またはポートが違う', '接続先の起動状態とポートを確認', 'any'),
    ('ETIMEOUT', r'ETIMEDOUT|timed out', 'ネットワーク', '外部サービス・ネットワーク', '応答が遅い、またはプロキシ・ファイアウォールで遮断', '別経路で同じ要求を送って比べる', 'any'),
    ('HTTP401', r'\b401\b|Unauthorized', 'HTTP認証', '認証・設定', 'キーが無い、誤り、または期限切れ', 'キーの有無を確認（値は表示しない）', 'any'),
    ('HTTP403', r'\b403\b|Forbidden', 'HTTP認証', '認証・権限', '権限が足りない', '対象リソースの権限設定を確認', 'any'),
    ('HTTP404', r'\b404\b|Not Found', 'HTTP', 'API・設定', 'パスの誤り、または対象が存在しない', 'URLとエンドポイント名を公式と照合', 'any'),
    ('HTTP429', r'\b429\b|Too Many Requests|rate limit', 'HTTP', '外部サービス', '送信が多すぎる', '送信間隔を空け、再送の待機を入れる', 'any'),
    ('HTTP5XX', r'\b5\d\d\b|Internal Server Error', 'HTTP', '外部サービス', '相手側の不具合', '相手側のステータスとリクエストIDを確認', 'any'),
    ('RESOURCE', r'No space left on device|ENOSPC|MemoryError|out of memory', 'リソース', 'OS', '容量またはメモリ不足', 'df -h、メモリ使用量を確認', 'any'),
    ('LOCK', r'database is locked|deadlock|Lock wait timeout', '競合', 'データ・並行処理', '同時書き込みやロックの順序', '同時実行の箇所とトランザクション範囲を確認', 'any'),
]

REFS = [
    '査読付き：Ko & Myers（2005）J. Vis. Lang. Comput. 16(1–2), 41–84（DOI未確認。書誌で示す）',
    '査読付き（作業部会）：Becker ほか（2019）ITiCSE-WGR ’19, 177–210, https://doi.org/10.1145/3344429.3372508',
    '報告（査読付き論文ではない）：Dagstuhl Seminar 22052, DagRep 12(1), 119–130, https://doi.org/10.4230/DagRep.12.1.119',
    '公式：Node.js Errors, https://nodejs.org/docs/latest/api/errors.html（確認済み）',
    '公式：Python 例外の一覧（公式サイトで確認。使用中の版と合わせる）',
]


def frames(text):
    """(path, line) の列。Python は File 行、Node は (path:line:col) 形式。"""
    out = []
    for m in re.finditer(r'File "([^"]+)", line (\d+)', text):
        out.append((m.group(1), m.group(2), 'py'))
    for m in re.finditer(r'\(?((?:/|[A-Za-z]:\\)[^\s:()]+\.\w+):(\d+)(?::\d+)?\)?', text):
        out.append((m.group(1), m.group(2), 'js'))
    return out


def own(fr):
    return [f for f in fr if 'site-packages' not in f[0] and 'node_modules' not in f[0] and not f[0].startswith('/usr/')]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('log')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    text = open(a.log, encoding='utf-8', errors='ignore').read()
    is_py = 'Traceback (most recent call last)' in text
    lang = 'py' if is_py else 'js'
    hits = [r for r in RULES if re.search(r[1], text) and r[6] in (lang, 'any')]
    fr = own(frames(text))
    where = None
    if fr:
        where = fr[-1] if is_py else fr[0]  # Python は最も内側、Node は最初の行
    L = ['# エラー分析（Python特化・Node.js対応）' if is_py else '# エラー分析（Node.js）', '', f'対象：{a.log}', f'言語の判定：{"Python（Traceback）" if is_py else "JavaScript/Node.js または不明"}', '']
    if hits:
        top = hits[0]
        L += ['## 結論（仮説）', '', f'- 種類：{top[2]}　／　発生層：{top[3]}', f'- 最有力の仮説：{top[4]}', '']
    else:
        L += ['該当するパターンが見つかりませんでした。エラーの最後の行と、スタックトレースを提供してください。', '']
    if where:
        note = '最も内側（発生箇所）' if is_py else '最初の行（発生箇所）'
        L += [f'{note}の自分のコード：`{where[0]}:{where[1]}`', '']
    if len(fr) > 1:
        L += ['自分のコードの呼び出し経路（上が呼び出し元）：'] + [f'- `{p}:{l}`' for p, l, _ in fr] + ['']
    if hits:
        L += ['## 仮説の一覧（確からしさ順）', '', '| 仮説 | 種類 | 確かめ方 |', '|---|---|---|']
        L += [f'| {r[4]} | {r[2]} | {r[5]} |' for r in hits] + ['']
    L += ['## 切り分けの基本順', '', '1. 最初（Node）／最も内側（Python）のエラーを特定する',
          '2. 最小の入力で再現する（一度に一つだけ変える）', '3. 直前の変更を戻して、再現するか確かめる', '']
    L += ['## 改善提案（再発防止）', '', '- 再現する回帰テストを追加する（Python は pytest、Node.js は node:test などで）',
          '- 境界で入力を検証し、不正な値は早めに弾く',
          '- 想定の例外・エラーだけを捕まえ、説明つきで返す。想定外は投げ直す（広い except で握りつぶさない）',
          '- エラーに識別子（code、リクエストID）と入力の要点を含める',
          '- 仕様の曖昧さと API の誤用を、レビューのチェックリストに入れる（Ko & Myers, 2005）',
          '- エラーメッセージの分かりやすさを評価する（Becker ほか, 2019 の観点）', '']
    L += ['## 根拠（確認状況つき）', ''] + [f'- {r}' for r in REFS] + ['']
    open(a.out, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print(f"wrote {a.out}（言語：{lang}、該当 {len(hits)} 件）")


if __name__ == '__main__':
    main()
