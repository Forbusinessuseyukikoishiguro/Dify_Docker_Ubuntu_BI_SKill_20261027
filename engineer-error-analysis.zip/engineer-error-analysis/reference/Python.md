# Python のエラー（分類と確かめ方）

Python のトレースバック（Traceback）は、上が呼び出し元、下が発生した場所。原因の候補は、最後の「File」行（自分のコードの最下段）から読む。

| 例外 | 典型の原因 | 確かめ方 | 参照 |
|---|---|---|---|
| ModuleNotFoundError / ImportError | 未インストール、仮想環境の違い | `python -c "import sys; print(sys.executable)"` で実行中の Python を確認。`pip show 名前` | Python 公式（確認要） |
| NameError | 変数の綴り違い、宣言の順序 | 変数の定義行と綴りを確認 | 同上 |
| AttributeError: 'NoneType' object has no attribute | 戻り値が None（関数が return していない） | 直前の戻り値を print | 同上 |
| TypeError | 引数の数・型の不一致 | 関数のシグネチャと呼び出しを比べる | 同上 |
| KeyError | 辞書に無いキー | `dict.get` で既定値、またはキーの存在を確認 | 同上 |
| IndexError | 範囲外のインデックス | 長さを `len` で出力 | 同上 |
| ValueError | 値の形式が違う（例：int変換） | 入力の生の値を repr で出力 | 同上 |
| ZeroDivisionError | 0 で割った | 除数の値を確認 | 同上 |
| FileNotFoundError | ファイルがない、カレントフォルダ違い | `os.getcwd()` と絶対パスを出力 | 同上 |
| PermissionError | 権限不足 | 所有者と権限を確認 | 同上 |
| json.JSONDecodeError | 応答が JSON ではない（HTML のエラーページ等） | 応答の先頭を repr で出力 | 同上 |
| UnicodeDecodeError | 文字コードの指定違い | `open(..., encoding=...)` を明示 | 同上 |
| RecursionError | 再帰の終了条件がない | 終了条件と引数の変化を確認 | 同上 |
| requests の HTTPError | ステータスが 4xx/5xx | `response.status_code` と本文を確認 | 同上（ライブラリ側の文書） |

## Python 特有の注意
- 例外を広く捕まえて握りつぶす（`except:` だけ）と、原因が消える。例外の種類を指定する。
- `print` で値を見る時は、`repr()` を使うと空白や改行が分かる。
- 仮想環境（venv）を有効にしていないと、別の Python のパッケージを見ることがある。
- 公式の参照：Python 公式ドキュメント（例外の一覧）。URL は公式サイトで確認し、使用中の版と合わせる。
