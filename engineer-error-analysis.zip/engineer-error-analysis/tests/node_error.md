# エラー分析（Node.js）

対象：../tests/node_error.txt
言語の判定：JavaScript/Node.js または不明

## 結論（仮説）

- 種類：型・値　／　発生層：コード・データ
- 最有力の仮説：値が undefined/null のまま使われた

最初の行（発生箇所）の自分のコード：`/home/user/app/index.js:4`

自分のコードの呼び出し経路（上が呼び出し元）：
- `/home/user/app/index.js:4`
- `/home/user/app/index.js:8`

## 仮説の一覧（確からしさ順）

| 仮説 | 種類 | 確かめ方 |
|---|---|---|
| 値が undefined/null のまま使われた | 型・値 | 直前の値を出力し、無い理由を確認 |

## 切り分けの基本順

1. 最初（Node）／最も内側（Python）のエラーを特定する
2. 最小の入力で再現する（一度に一つだけ変える）
3. 直前の変更を戻して、再現するか確かめる

## 改善提案（再発防止）

- 再現する回帰テストを追加する（Python は pytest、Node.js は node:test などで）
- 境界で入力を検証し、不正な値は早めに弾く
- 想定の例外・エラーだけを捕まえ、説明つきで返す。想定外は投げ直す（広い except で握りつぶさない）
- エラーに識別子（code、リクエストID）と入力の要点を含める
- 仕様の曖昧さと API の誤用を、レビューのチェックリストに入れる（Ko & Myers, 2005）
- エラーメッセージの分かりやすさを評価する（Becker ほか, 2019 の観点）

## 根拠（確認状況つき）

- 査読付き：Ko & Myers（2005）J. Vis. Lang. Comput. 16(1–2), 41–84（DOI未確認。書誌で示す）
- 査読付き（作業部会）：Becker ほか（2019）ITiCSE-WGR ’19, 177–210, https://doi.org/10.1145/3344429.3372508
- 報告（査読付き論文ではない）：Dagstuhl Seminar 22052, DagRep 12(1), 119–130, https://doi.org/10.4230/DagRep.12.1.119
- 公式：Node.js Errors, https://nodejs.org/docs/latest/api/errors.html（確認済み）
- 公式：Python 例外の一覧（公式サイトで確認。使用中の版と合わせる）

