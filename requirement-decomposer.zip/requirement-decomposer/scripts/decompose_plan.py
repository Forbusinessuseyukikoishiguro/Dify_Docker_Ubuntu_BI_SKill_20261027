#!/usr/bin/env python3
"""分解済みの要件（要件.json）から、ToDo・依存関係・リスク・決定事項の資料（Excel・Notion・Word用）を作る。

使い方:
  python3 decompose_plan.py 要件.json --out ./出力

要件.json の形は tests/sample_plan.json を参照。
検査：循環依存、存在しない依存先、完了条件の欠落、所要時間の欠落。クリティカルパスを計算する。
"""
import argparse
import csv
import json
import os
import subprocess

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

F = 'Arial'
HF = PatternFill('solid', fgColor='1F3864')
INP = PatternFill('solid', fgColor='FFF2CC')
thin = Side(style='thin', color='BFBFBF')
BOX = Border(left=thin, right=thin, top=thin, bottom=thin)


def check(items):
    ids = {i['id'] for i in items}
    warns = []
    for it in items:
        for d in it.get('depends_on', []):
            if d not in ids:
                warns.append(f"{it['id']}：依存先 {d} が存在しない")
        if not it.get('done_when'):
            warns.append(f"{it['id']}：完了条件がない（ToDoにしない、または完了条件を書く）")
        if it.get('hours') is None:
            warns.append(f"{it['id']}：所要時間がない（見積もりを入れる）")
    # 循環検出（DFS）
    graph = {i['id']: [d for d in i.get('depends_on', []) if d in ids] for i in items}
    state = {}
    cycles = []

    def dfs(n, stack):
        state[n] = 1
        for m in graph.get(n, []):
            if state.get(m) == 1:
                cycles.append(' → '.join(stack + [m]))
            elif state.get(m) is None:
                dfs(m, stack + [m])
        state[n] = 2
    for n in graph:
        if state.get(n) is None:
            dfs(n, [n])
    for c in cycles:
        warns.append(f'循環依存：{c}')
    return warns, graph


def critical_path(items, graph):
    hours = {i['id']: float(i.get('hours') or 0) for i in items}
    memo = {}

    def longest(n):
        if n in memo:
            return memo[n]
        best = (0.0, [])
        for d in graph.get(n, []):
            cand = longest(d)
            if cand[0] > best[0]:
                best = cand
        memo[n] = (best[0] + hours.get(n, 0), best[1] + [n])
        return memo[n]
    if not graph:
        return 0.0, []
    total, path = max((longest(n) for n in graph), key=lambda x: x[0])
    return total, path


def write_excel(path, items, risks, decisions, warns, cp):
    wb = Workbook()
    wb.remove(wb.active)

    def sheet(name, headers, rows, widths, inp_from=None):
        ws = wb.create_sheet(name)
        for i, h in enumerate(headers, 1):
            c = ws.cell(row=1, column=i, value=h)
            c.font = Font(name=F, bold=True, color='FFFFFF', size=10)
            c.fill = HF
            c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            c.border = BOX
        for r, row in enumerate(rows, 2):
            for c, v in enumerate(row, 1):
                cell = ws.cell(row=r, column=c, value=v)
                cell.font = Font(name=F, size=10)
                cell.alignment = Alignment(wrap_text=True, vertical='top')
                cell.border = BOX
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.freeze_panes = 'A2'
        return ws

    rows = []
    for it in items:
        rows.append([it['id'], it.get('category', ''), it['title'], it.get('owner', '要確認'), ', '.join(it.get('depends_on', [])) or '-',
                     it.get('hours'), it.get('start', ''), it.get('due', ''), it.get('status', '未着手'), it.get('done_when', '（未記入）'), it.get('source', '')])
    ws = sheet('ToDo', ['ID', '区分', 'ToDo', '担当（役割）', '依存先', '所要時間(h)', '開始', '期限', '状態', '完了条件', '出典'],
               rows, [9, 14, 36, 14, 14, 12, 12, 12, 10, 36, 22])
    n = len(rows)
    for r in range(2, n + 2):
        for c in (6,):
            ws.cell(row=r, column=c).fill = INP
        ws.cell(row=r, column=9).fill = INP
    dvs = __import__('openpyxl').worksheet.datavalidation.DataValidation(type='list', formula1='"未着手,進行中,完了,保留"', allow_blank=True)
    ws.add_data_validation(dvs)
    dvs.add(f'I2:I{n + 60}')

    s = wb.create_sheet('サマリ', 0)
    s['A1'] = '計画サマリ（自動計算）'
    s['A1'].font = Font(name=F, bold=True, size=13, color='1F3864')
    last = n + 1
    lines = [
        ('ToDoの数', f'=COUNTA(ToDo!A2:A{last})'),
        ('合計所要時間（h）', f'=SUM(ToDo!F2:F{last})'),
        ('完了の数', f'=COUNTIF(ToDo!I2:I{last},"完了")'),
        ('完了率', f'=IFERROR(B5/B3,0)'),
        ('クリティカルパスの合計（h、見積もり）', round(cp[0], 1)),
        ('クリティカルパス（ToDo ID）', ' → '.join(cp[1]) if cp[1] else '-'),
        ('検査の指摘（件数）', len(warns)),
    ]
    for i, (k, v) in enumerate(lines, 3):
        s.cell(row=i, column=1, value=k).font = Font(name=F, bold=True, size=10)
        c = s.cell(row=i, column=2, value=v)
        c.font = Font(name=F, size=10)
    s['B6'].number_format = '0%'
    s.column_dimensions['A'].width = 40
    s.column_dimensions['B'].width = 50
    s['A12'] = '指摘'
    s['A12'].font = Font(name=F, bold=True, size=10)
    for i, w in enumerate(warns or ['なし'], 13):
        s.cell(row=i, column=1, value=w).font = Font(name=F, size=10)

    sheet('依存関係', ['ToDo ID', '前提（依存先）'], [[i['id'], ', '.join(i.get('depends_on', [])) or '-'] for i in items], [14, 40])
    sheet('リスク', ['リスクID', 'リスク', '影響（高・中・低）', '発生の見込み（高・中・低）', '対応', '担当（役割）', '状態'],
          [[r['id'], r['risk'], r.get('impact', ''), r.get('likelihood', ''), r.get('response', ''), r.get('owner', '要確認'), '未対応'] for r in risks],
          [10, 36, 14, 16, 36, 14, 10])
    sheet('決定事項', ['決定ID', '判断が必要な事項', '選択肢', '決める人（役割）', '期限', '状態'],
          [[d['id'], d['question'], d.get('options', ''), d.get('decider', '要確認'), d.get('due', ''), '未決'] for d in decisions],
          [10, 40, 36, 16, 12, 10])
    wb.save(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('plan')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d = json.load(open(a.plan, encoding='utf-8'))
    items = d['items']
    risks = d.get('risks', [])
    decisions = d.get('decisions', [])
    warns, graph = check(items)
    cp = critical_path(items, graph)
    os.makedirs(a.out, exist_ok=True)
    write_excel(os.path.join(a.out, '計画.xlsx'), items, risks, decisions, warns, cp)
    os.makedirs(os.path.join(a.out, 'notion'), exist_ok=True)
    with open(os.path.join(a.out, '計画_ToDo.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['ID', '区分', 'ToDo', '担当', '依存先', '所要時間(h)', '期限', '状態', '完了条件'])
        for i in items:
            w.writerow([i['id'], i.get('category', ''), i['title'], i.get('owner', '要確認'), ', '.join(i.get('depends_on', [])), i.get('hours', ''), i.get('due', ''), i.get('status', '未着手'), i.get('done_when', '')])
    md = [f"# {d['goal']}", '', f"- 合計見積もり：{sum(float(i.get('hours') or 0) for i in items):.1f} h（仮の見積もり）",
          f"- クリティカルパス：{' → '.join(cp[1]) if cp[1] else '-'}", '', '## ToDo', '']
    for i in items:
        md.append(f"- [ ] **{i['id']}** {i['title']}（担当：{i.get('owner', '要確認')}／{i.get('hours', '?')}h）")
        md.append(f"  - 完了条件：{i.get('done_when', '（未記入）')}")
        if i.get('depends_on'):
            md.append(f"  - 前提：{', '.join(i['depends_on'])}")
    md += ['', '## リスク', ''] + [f"- {r['id']}：{r['risk']}（影響：{r.get('impact', '')}／見込み：{r.get('likelihood', '')}）" for r in risks]
    md += ['', '## 判断が必要な事項', ''] + [f"- {x['id']}：{x['question']}（決める人：{x.get('decider', '要確認')}）" for x in decisions]
    md += ['', '## 検査の指摘', ''] + ([f'- {w}' for w in warns] or ['- なし'])
    text = '\n'.join(md) + '\n'
    open(os.path.join(a.out, 'notion', '計画.md'), 'w', encoding='utf-8').write(text)
    open(os.path.join(a.out, '計画メモ.md'), 'w', encoding='utf-8').write(text)
    try:
        subprocess.run(['pandoc', os.path.join(a.out, '計画メモ.md'), '-o', os.path.join(a.out, '計画メモ.docx')], check=True)
    except Exception as e:
        print('Word変換に失敗：', e)
    for w in warns:
        print('WARN:', w)
    print(f'wrote {a.out}（ToDo {len(items)} 件、指摘 {len(warns)} 件）')


if __name__ == '__main__':
    main()
