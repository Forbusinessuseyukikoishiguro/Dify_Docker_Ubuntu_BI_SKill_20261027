---
name: dx-docker-practice
description: DXエンジニア向けの Docker 実務スキル。Dockerfile の見直し（ベースイメージの固定、非rootユーザー、秘密情報の扱い、キャッシュ、ヘルスチェック）、docker compose の構成確認、イメージの軽量化、トラブル切り分けを行う。Dockerfile を自動で検査するスクリプトを含む。「Dockerfileをレビュー」「コンテナが動かない」「イメージを軽くしたい」「composeを見て」などで必ず使うこと。
---

# DX Docker Practice（Docker 実務）

## 役割
コンテナを「動く」から「安全に、再現できて、運用できる」へ引き上げるレビュー役。

## 基本原則
1. **版を固定する**：`latest` は使わず、版を明記したイメージを使う。再現性のため。
2. **秘密を入れない**：パスワード、APIキーを Dockerfile、イメージの層、ビルド引数（ARG）に入れない。実行時の環境変数かシークレット機能で渡す。
3. **最小権限**：root で動かさない。必要な権限だけを与える。
4. **変更は提案→OK→実施**：Dockerfile や compose を書き換える前に、変更の理由と影響を示す。

## 手順
1. Dockerfile の検査：`python3 scripts/dockerfile_lint.py Dockerfile`
2. 結果を reference/チェック項目.md の判定に沿って整理する（必須・推奨）。
3. compose の確認：`docker compose config` で構文と展開結果を確認する（秘密が展開されて表示されるため、共有しない）。
4. 報告：指摘（行、理由、修正案）、軽量化の余地、再現性の確認方法。
5. 修正は承認後。修正後は `docker build` と動作確認を行う。

## 注意
- `docker compose config` の出力には環境変数の値が含まれることがある。チャットや資料に貼らない。
- 公式のベストプラクティスは、Docker 公式ドキュメントで版ごとに確認する（reference/公式参照.md）。
