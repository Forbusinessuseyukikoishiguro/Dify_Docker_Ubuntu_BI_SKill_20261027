#!/usr/bin/env python3
"""Dockerfile を検査する（読み取り専用）。判定は reference/チェック項目.md と対応する。

使い方:
  python3 dockerfile_lint.py Dockerfile
"""
import re
import sys

SECRET = re.compile(r'(?i)\b(password|passwd|secret|token|api[_-]?key|access[_-]?key)\b\s*=?\s*\S+')


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else 'Dockerfile'
    lines = open(path, encoding='utf-8').read().splitlines()
    text = '\n'.join(lines)
    out = []

    def add(i, level, where, msg):
        out.append((level, i, where, msg))

    froms = [(i, l) for i, l in enumerate(lines, 1) if re.match(r'^\s*FROM\s+', l, re.I)]
    for i, l in froms:
        img = re.split(r'\s+', l.strip())[1]
        base = img.split(' AS ')[0].split(' as ')[0]
        if base.endswith(':latest') or (':' not in base and '@' not in base):
            add(i, '必須', 'D-01', f'ベースイメージが版で固定されていない：{base}')
    if not re.search(r'^\s*USER\s+(?!root\b)\S+', text, re.M | re.I):
        add(0, '必須', 'D-02', 'USER が設定されていない、または root のまま')
    for i, l in enumerate(lines, 1):
        if re.match(r'^\s*(ENV|ARG)\s+', l, re.I) and SECRET.search(l):
            add(i, '必須', 'D-03', '秘密らしき値が ENV/ARG に書かれている（イメージに残る）')
        if re.search(r'apt-get\s+install', l) and '--no-install-recommends' not in l:
            add(i, '推奨', 'D-06', 'apt-get install に --no-install-recommends がない')
        if re.search(r'^\s*ADD\s+', l, re.I) and not re.search(r'https?://|\.tar', l):
            add(i, '推奨', 'D-09', 'ADD を使っている（COPY で足りる可能性）')
    if re.search(r'apt-get\s+install', text) and not re.search(r'rm\s+-rf\s+/var/lib/apt/lists', text):
        add(0, '推奨', 'D-05', 'apt-get のキャッシュ削除（rm -rf /var/lib/apt/lists/*）がない')
    if not re.search(r'^\s*HEALTHCHECK\s+', text, re.M | re.I):
        add(0, '推奨', 'D-07', 'HEALTHCHECK がない（常駐サービスの場合は推奨）')
    import os
    if not os.path.exists(os.path.join(os.path.dirname(os.path.abspath(path)), '.dockerignore')):
        add(0, '推奨', 'D-04', '.dockerignore が見当たらない')
    copy_i = next((i for i, l in enumerate(lines, 1) if re.match(r'^\s*COPY\s+', l, re.I)), None)
    inst_i = next((i for i, l in enumerate(lines, 1) if re.search(r'(pip|npm|yarn|poetry|bundle)\s+install', l)), None)
    if copy_i and inst_i and copy_i < inst_i and not re.search(r'COPY\s+.*(requirements|package)', text):
        add(copy_i, '推奨', 'D-08', '依存関係の定義を先にコピーしていないため、キャッシュが効きにくい')
    if not out:
        print('問題なし（自動チェックの範囲で）')
    else:
        for level, i, where, msg in sorted(out, key=lambda x: (x[0] != '必須', x[1])):
            loc = f'{i}行目' if i else '全体'
            print(f'[{level}] {where} {loc}：{msg}')
    return 1 if any(o[0] == '必須' for o in out) else 0


if __name__ == '__main__':
    sys.exit(main())
