#!/usr/bin/env python3
"""メモ（memo.json）から、README・要件定義書・詳細設計書・実装仕様書の提案（DRAFT）を作る。

使い方:
  python3 plan_docs.py memo.json --out ./計画/DRAFT

- すべての文書は DRAFT（提案）。承認されるまで実装しない。
- ID（REQ・ACC・DES・TASK・TEST）でつながる。
- 不明な点は「要確認」として残す。
"""
import argparse
import json
import os


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('memo')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d = json.load(open(a.memo, encoding='utf-8'))
    os.makedirs(a.out, exist_ok=True)
    name = d['project']
    reqs = d['requirements']
    tasks = d['tasks']
    tests = d['tests']
    des = d.get('design', [])
    unknown = d.get('unknown', [])

    def w(fn, lines):
        open(os.path.join(a.out, fn), 'w', encoding='utf-8').write('\n'.join(lines) + '\n')

    w('README.md', [f'# {name}（提案・DRAFT）', '', f"目的：{d['purpose']}", '',
                    '## 状態', '- 本書は提案です。承認されるまで実装しません。', '',
                    '## 文書', '- 要件定義書.md', '- 詳細設計書.md', '- 実装仕様書.md', '',
                    '## 要確認', *([f'- {u}' for u in unknown] or ['- なし']), '',
                    '## 起動方法（実装後に記入）', '- 要確認'])

    req_lines = [f'# 要件定義書（{name}・DRAFT）', '', '## 1. 目的・背景', d['purpose'], '', '## 2. 利用者', d.get('users', '要確認'), '',
                 '## 3. 要件（REQ）']
    for r in reqs:
        req_lines.append(f"- {r['id']}：{r['text']}（優先度：{r.get('priority', 'Must')}）")
    req_lines += ['', '## 4. 受け入れ基準（ACC）']
    for r in reqs:
        for acc in r.get('acceptance', []):
            req_lines.append(f"- {acc['id']}（対応：{r['id']}）：{acc['text']}")
    req_lines += ['', '## 5. 出典・根拠', '- 要求の書き方：ISO/IEC/IEEE 29148:2018（適用の参考。適合の証明ではない）', '']
    w('要件定義書.md', req_lines)

    des_lines = [f'# 詳細設計書（{name}・DRAFT）', '', '## 1. 構成（層）', '- 画面（UI）', '- API', '- ドメイン（業務ルール）', '- データ', '',
                 '## 2. 設計決定（情報隠蔽）', '- 変わりやすい決定（保存先、外部サービス）は、一か所に閉じる（Parnas, 1972）。', '', '## 3. 設計項目（DES）']
    for x in des:
        des_lines.append(f"- {x['id']}（対応：{x['req']}）：{x['text']}")
    w('詳細設計書.md', des_lines)

    impl = [f'# 実装仕様書（{name}・DRAFT）', '', '## 1. タスク（TASK）']
    for t in tasks:
        dep = ', '.join(t.get('depends_on', [])) or '-'
        impl.append(f"- {t['id']} [対応: {t['req']}] [依存: {dep}]：{t['text']}")
    impl += ['', '## 2. テスト（TEST）']
    for x in tests:
        impl.append(f"- {x['id']} [対象: {x['acc']}]：{x['text']}")
    impl += ['', '## 3. 完了の定義', '- 対応する TEST が合格している。', '- 変更したファイルとテスト結果（件数と合否）を報告した。']
    w('実装仕様書.md', impl)
    print(f'wrote {a.out}（要件 {len(reqs)}、タスク {len(tasks)}、テスト {len(tests)}）')


if __name__ == '__main__':
    main()
