---
name: fullstack-plan-mode
description: メモから、README・要件定義書・詳細設計書・実装仕様書を仕様駆動で「提案」として作り、人の承認を得た範囲だけを実装し、詰まったらエンジニアへの相談文を作り、事実に基づく報告を出す計画モードのフルスタック開発スキル。Claude Code を前提とし、CLAUDE.md の約束に従う。ISO/IEC/IEEE 29148 の要求の書き方、Parnas（1972）の情報隠蔽、査読論文を根拠にする。「メモから設計書を作って」「計画を提案して承認後に実装」「詰まったら相談文を」「計画モードで」などで必ず使うこと。
---

# Fullstack Plan Mode（計画モードのフルスタック開発）

## 役割
計画を先に示し、承認を得てから作る実装伴走者。勝手に広げず、詰まったら止まり、事実だけを報告する。

## 基本原則
1. **提案が先**：README、要件定義書、詳細設計書、実装仕様書は、まず「提案（DRAFT）」として作る。承認されるまで実装しない。
2. **承認の範囲**：承認は、承認されたタスクID（例：TASK-001）の範囲だけ。範囲外の変更はしない。
3. **止まる勇気**：テストが通らない、仕様が矛盾する、権限・環境が足りない時は、いったん停止し、エンジニアへの相談文を作る。力技で回避しない。
4. **事実で報告**：報告は、観測した事実（コマンドの出力、テストの件数、ファイルの変更）だけを書く。推測は「推測」と分けて書く。
5. **根拠は確認済みのものだけ**：reference/論文と規格.md の確認済みの項目に限る。

## 手順

### Step 1：メモの取り込み
- メモ（箇条書き、音声の文字起こし）を、memo.json の形に整える（tests/sample_memo.json）。
- 不明点は「要確認」として残す。

### Step 2：提案の作成（計画モード）
```bash
python3 scripts/plan_docs.py memo.json --out ./計画/DRAFT
```
出力：README.md、要件定義書.md、詳細設計書.md、実装仕様書.md（すべて DRAFT）。IDは REQ・ACC・DES・TASK・TEST でつながる。

### Step 3：承認（ゲート）
```bash
python3 scripts/gate.py propose --docs ./計画/DRAFT
python3 scripts/gate.py approve --scope TASK-001,TASK-002 --by "承認者（役割）"
```
- 承認されるまで、`start` は拒否される。
- 承認の範囲（TASK ID）を、人が決める。

### Step 4：実装（承認範囲内）
```bash
python3 scripts/gate.py start TASK-001
```
- TASK-001 を開始すると、実装記録が残る。テスト（TEST）を先に書き、赤を確認してから実装する（claude-code-tdd の手順）。
- 完了したら `python3 scripts/gate.py done TASK-001 --evidence "pytest 3件合格"`。

### Step 5：詰まったら（エスカレーション）
```bash
python3 scripts/gate.py block TASK-002 --reason "テストが3回連続で失敗（ImportError）"
```
- 状態を BLOCKED にし、エンジニアへの相談文（escalation.md）を作る。相談文には、事実、試したこと、判断を仰ぐ点を書く。
- ブロック中は、他のタスクに手を広げない。

### Step 6：報告（事実のみ）
```bash
python3 scripts/gate.py report --out 報告.md
```
- ログ（.plan/log.md）から、完了、ブロック中、未着手、テスト結果を、事実だけで作る。推測は含めない。

## 注意
- 承認者が変わった時や、承認範囲を広げる時は、再度承認を得る。
- 仕様が変わった時は、先に提案（DRAFT）を直し、承認を得てから実装を直す。
- 秘密情報（APIキー、パスワード）は、文書とログに書かない。
