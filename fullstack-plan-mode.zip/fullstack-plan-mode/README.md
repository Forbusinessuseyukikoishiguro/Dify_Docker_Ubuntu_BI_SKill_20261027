# fullstack-plan-mode（計画モードのフルスタック開発）

メモから、README・要件定義書・詳細設計書・実装仕様書を「提案」として作り、承認された範囲だけを実装し、詰まったらエンジニアへの相談文を作り、事実に基づく報告を出すためのスキルです。

## 構成
- `SKILL.md`：手順（提案 → 承認 → 実装 → 相談 → 報告）
- `scripts/plan_docs.py`：メモ（memo.json）から4文書の提案（DRAFT）を作る
- `scripts/gate.py`：状態管理（提案、承認、開始、完了、ブロック、報告）
- `reference/報告と相談.md`：事実の書き方と相談文の型
- `reference/論文と規格.md`：根拠（確認状況つき）
- `tests/sample_memo.json`：サンプルのメモ

## 使い方（最短）
```bash
python3 scripts/plan_docs.py tests/sample_memo.json --out ./計画/DRAFT
python3 scripts/gate.py propose --docs ./計画/DRAFT
python3 scripts/gate.py approve --scope TASK-001 --by "承認者（役割）"
python3 scripts/gate.py start TASK-001
python3 scripts/gate.py done TASK-001 --evidence "テスト件数と合否"
python3 scripts/gate.py report --out 報告.md
```

## ゲートの動き
- 承認前の `start` は拒否される
- 承認範囲外のタスクは `start` できない
- `block` で、エンジニアへの相談文（.plan/escalation_TASK-xxx.md）を作る
- 状態は `.plan/state.json`、経過は `.plan/log.md` に残る

## 注意
- 提案の内容（数値、設計判断）は、人が決める。サンプルの値は仮。
- 秘密情報（APIキー、パスワード）は文書とログに書かない。
- 規格は参考。準拠や認証の根拠として書かない。
