#!/usr/bin/env python3
"""フォルダの中に、Notionのトークンらしき文字列が書かれていないかを調べる（値は表示しない）。

使い方:
  python3 scan_secrets.py ./作業フォルダ
"""
import os
import re
import sys

PATTERNS = [
    (re.compile(r'\bsecret_[A-Za-z0-9]{20,}'), 'secret_ 形式のトークンらしき文字列'),
    (re.compile(r'\bntn_[A-Za-z0-9]{20,}'), 'ntn_ 形式のトークンらしき文字列'),
    (re.compile(r'Bearer\s+(?!\$|\{|<)[A-Za-z0-9_\-]{20,}'), 'Bearer に直書きされた値'),
]
SKIP = {'.git', 'node_modules', '__pycache__', '.venv'}


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else '.'
    hits = 0
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in SKIP]
        for f in fn:
            p = os.path.join(dp, f)
            try:
                text = open(p, encoding='utf-8').read()
            except Exception:
                continue
            for pat, label in PATTERNS:
                for m in pat.finditer(text):
                    line = text[:m.start()].count('\n') + 1
                    print(f'要確認：{p}:{line}：{label}（値は表示しません）')
                    hits += 1
    print('問題なし' if hits == 0 else f'{hits} 件。該当のトークンは無効化して作り直し、コードから取り除いてください。')
    return 1 if hits else 0


if __name__ == '__main__':
    sys.exit(main())
