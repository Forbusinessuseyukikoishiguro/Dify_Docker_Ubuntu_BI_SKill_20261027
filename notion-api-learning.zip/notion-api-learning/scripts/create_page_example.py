#!/usr/bin/env python3
"""演習02：親ページの下に、タイトルつきのページを作る（学習用の例）。

使い方:
  export NOTION_TOKEN="..."
  export NOTION_PARENT_PAGE_ID="親ページのID"
  python3 create_page_example.py "練習ページ"

- トークンは環境変数から読む（コードに書かない）。
- 親ページは、インテグレーションに共有されている必要がある。
"""
import json
import os
import sys
import urllib.error
import urllib.request

VERSION = '2022-06-28'


def create_page(token, parent_id, title):
    body = {
        'parent': {'page_id': parent_id},
        'properties': {'title': {'title': [{'text': {'content': title}}]}},
    }
    req = urllib.request.Request(
        'https://api.notion.com/v1/pages',
        data=json.dumps(body, ensure_ascii=False).encode('utf-8'),
        headers={'Authorization': f'Bearer {token}', 'Notion-Version': VERSION, 'Content-Type': 'application/json'},
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=30) as res:
        return json.loads(res.read().decode('utf-8'))


def main():
    token = os.environ.get('NOTION_TOKEN', '')
    parent = os.environ.get('NOTION_PARENT_PAGE_ID', '')
    title = sys.argv[1] if len(sys.argv) > 1 else '練習ページ'
    if not token or not parent:
        print('NOTION_TOKEN と NOTION_PARENT_PAGE_ID を設定してください', file=sys.stderr)
        return 2
    try:
        page = create_page(token, parent, title)
    except urllib.error.HTTPError as e:
        print(f'HTTP {e.code}：エラーと対処.md を確認してください', file=sys.stderr)
        return 1
    print('作成しました：', page.get('url', '（URLなし）'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
