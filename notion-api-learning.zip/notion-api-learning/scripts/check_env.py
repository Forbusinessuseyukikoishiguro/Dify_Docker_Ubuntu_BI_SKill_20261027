#!/usr/bin/env python3
"""学習者の環境を確認する（トークンの値は表示しない）。

使い方:
  export NOTION_TOKEN="..."
  python3 check_env.py

確認すること：
1. NOTION_TOKEN が設定されているか（値は表示しない。形式だけを見る）
2. 版の指定（NOTION_VERSION。既定は本教材の版）
3. ネットワーク接続（任意：--online を付けた時だけ、api.notion.com に1回だけ問い合わせる）
"""
import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request

DEFAULT_VERSION = '2022-06-28'  # 教材の版。公式リファレンスと合わせて変更する


def headers(token, version):
    return {'Authorization': f'Bearer {token}', 'Notion-Version': version, 'Content-Type': 'application/json'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--online', action='store_true', help='api.notion.com に1回だけ問い合わせる')
    a = ap.parse_args()
    token = os.environ.get('NOTION_TOKEN', '')
    version = os.environ.get('NOTION_VERSION', DEFAULT_VERSION)
    ok = True
    if not token:
        print('NG: NOTION_TOKEN が未設定です（export NOTION_TOKEN=... を実行）')
        ok = False
    else:
        shape = 'secret_ または ntn_ で始まる形式' if re.match(r'^(secret_|ntn_)', token) else '形式が想定と違う（前後の空白を確認）'
        print(f'OK: NOTION_TOKEN は設定されています（長さ {len(token)} 文字、{shape}）。値は表示しません。')
    print(f'INFO: Notion-Version = {version}')
    if a.online and token:
        req = urllib.request.Request('https://api.notion.com/v1/users/me', headers=headers(token, version))
        try:
            with urllib.request.urlopen(req, timeout=15) as res:
                data = json.loads(res.read().decode('utf-8'))
                print(f"OK: 接続できました（ボット名：{data.get('name', '（名前なし）')}）")
        except urllib.error.HTTPError as e:
            print(f'NG: HTTP {e.code}。トークンと版を確認（エラーと対処.md 参照）')
            ok = False
        except Exception as e:
            print(f'NG: 接続できません：{e.__class__.__name__}（ネットワーク設定を確認）')
            ok = False
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
