#!/usr/bin/env python3
"""事実（事実.json）から、読み手と媒体に合わせた報告文書を作り、検査する。

使い方:
  python3 write_report.py 事実.json --audience 上司 --out ./出力
  audience：新人 / 上司 / お客様 / 自分

事実.json の形は tests/sample_facts.json を参照。
推測は「推測（未確認）」と分けて書く。期限・担当・次の行動が無い時は「要確認」になる。
"""
import argparse
import csv
import json
import os
import re

BLAME = ['ミス', '怠慢', 'さぼ', '不注意のせい', '〜のせいで']
JARGON_FOR_CLIENT = ['デプロイ', 'リグレッション', 'スタブ', 'CI', 'マージ', 'コミット']


def check(text, audience, where):
    out = []
    for w in BLAME:
        if w in text:
            out.append(('必須', where, f'責める表現「{w}」（事実の書き方に直す）'))
    if audience == 'お客様':
        for w in JARGON_FOR_CLIENT:
            if w in text:
                out.append(('推奨', where, f'専門用語「{w}」（言い換える）'))
    if '要確認' in text:
        out.append(('推奨', where, '「要確認」が残っている（送る前に埋める）'))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('facts')
    ap.add_argument('--audience', required=True, choices=['新人', '上司', 'お客様', '自分'])
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    f = json.load(open(a.facts, encoding='utf-8'))
    os.makedirs(a.out, exist_ok=True)
    facts = f.get('facts', [])
    guesses = f.get('guesses', [])
    decisions = f.get('decisions', [])
    nxt = f.get('next', {})
    who = nxt.get('who') or '要確認'
    due = nxt.get('due') or '要確認'
    what = nxt.get('what') or '要確認'
    head = f.get('headline', '要確認')
    title = f.get('title', '作業報告')
    tests = f.get('tests')

    # 1. チャット
    chat = [f"【{title}】{head}"]
    chat += [f'・{x}' for x in facts[:3]]
    if guesses:
        chat.append(f'推測（未確認）：{guesses[0]}')
    chat.append(f'次の行動：{what}（担当：{who}／期限：{due}）')
    if a.audience == 'お客様':
        chat[0] = f'【ご報告】{head}'
    chat_txt = '\n'.join(chat) + '\n'
    open(os.path.join(a.out, 'チャット.txt'), 'w', encoding='utf-8').write(chat_txt)

    # 2. スプレッドシート行
    with open(os.path.join(a.out, 'スプレッドシート行.csv'), 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['日付', '件名', '担当（役割）', '状態', '事実（要点）', '推測（未確認）', '次の行動', '期限'])
        w.writerow([f.get('date', '要確認'), title, who, f.get('status', '要確認'), ' / '.join(facts[:3]),
                    ' / '.join(guesses) or '-', what, due])

    # 3. メモ
    memo = [f"{title}（{f.get('date', '')}）", f'- {head}']
    memo += [f'- {x}' for x in facts]
    if guesses:
        memo += [f'- 推測（未確認）：{x}' for x in guesses]
    memo += [f'- 次：{what}（{who}／{due}）']
    open(os.path.join(a.out, 'メモ.md'), 'w', encoding='utf-8').write('\n'.join(memo) + '\n')

    # 4. Googleドキュメント（見出し付き）
    doc = [f'# {title}', '', f'**結論**：{head}', '', '## 事実']
    doc += [f'- {x}' for x in facts] or ['- （なし）']
    doc += ['', '## 推測（未確認）']
    doc += [f'- {x}' for x in guesses] or ['- （なし）']
    doc += ['', '## 判断が必要な事項']
    doc += [f"- {d['question']}（決める人：{d.get('decider', '要確認')}／期限：{d.get('due', '要確認')}）" for d in decisions] or ['- （なし）']
    if tests:
        doc += ['', '## テスト結果', f"- 実施：{tests.get('run', 0)} 件、合格：{tests.get('pass', 0)} 件、不合格：{tests.get('fail', 0)} 件"]
        doc += [f"- 不合格 {t['id']}：期待「{t['expected']}」／実際「{t['actual']}」" for t in tests.get('failed', [])]
    doc += ['', '## 次の行動', f'- {what}（担当：{who}／期限：{due}）']
    doc_txt = '\n'.join(doc) + '\n'
    open(os.path.join(a.out, 'Googleドキュメント.md'), 'w', encoding='utf-8').write(doc_txt)

    # 5. 手順書（手順がある時のみ）
    steps = f.get('steps', [])
    if steps:
        sop = [f'# 手順書：{title}', '', f"対象：{a.audience}　／　前提：{f.get('premise', '要確認')}", '']
        for i, s in enumerate(steps, 1):
            sop += [f"## 手順{i}：{s['action']}", f"- 画面・場所：{s.get('where', '要確認')}",
                    f"- 期待される結果：{s.get('expect', '要確認')}", f"- 注意：{s.get('note', 'なし')}", '']
        sop += ['## 困ったとき', f"- 連絡先：{f.get('contact', '要確認')}"]
        open(os.path.join(a.out, '手順書.md'), 'w', encoding='utf-8').write('\n'.join(sop) + '\n')
        doc_for_check = '\n'.join(sop)
    else:
        doc_for_check = ''

    issues = []
    for name, txt in [('チャット', chat_txt), ('Googleドキュメント', doc_txt), ('メモ', '\n'.join(memo)), ('手順書', doc_for_check)]:
        issues += check(txt, a.audience, name)
    chk = ['# 検査結果', '']
    chk += ([f'| {l} | {w} | {m} |' for l, w, m in issues] and ['| 判定 | 場所 | 指摘 |', '|---|---|---|'] + [f'| {l} | {w} | {m} |' for l, w, m in issues]) or ['指摘なし（自動検査の範囲で）']
    chk += ['', f'読み手：{a.audience}。送る前に、推測と要確認の箇所を確認してください。']
    open(os.path.join(a.out, '検査結果.md'), 'w', encoding='utf-8').write('\n'.join(chk) + '\n')
    print(f'wrote {a.out}（指摘 {len(issues)} 件）')


if __name__ == '__main__':
    main()
