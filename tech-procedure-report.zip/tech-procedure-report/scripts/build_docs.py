#!/usr/bin/env python3
"""作業メモ（memo.json）から、手順書・報告（上司・新人）・自分用チェックリストを作り、検査する。

使い方:
  python3 build_docs.py memo.json --out ./出力

memo.json の形は tests/sample_memo.json を参照。
検査：一文の長さ、曖昧語、期待結果の欠落、一手順に複数の操作（「して」「て、」の連続）、未定義の略語。
"""
import argparse
import json
import os
import re

AMBIG = ['など', '適切', 'いい感じ', 'なんとか', '適宜', 'できるだけ', '速く', '適当']
MULTI = re.compile(r'(して|て、|たら、).*(して|する|押す|入力|開く)')
ACRO = re.compile(r'\b[A-Z][A-Z0-9]{1,}\b')


def sentences(text):
    return [s for s in re.split(r'(?<=[。！？])', text) if s.strip()]


def lint(doc_name, text, glossary):
    out = []
    for line in text.splitlines():
        if line.lstrip().startswith('#') or not line.strip():
            continue
        for s in sentences(line):
            if len(s) > 60:
                out.append(('推奨', doc_name, f'長い一文（{len(s)}字）：{s[:20]}…'))
    for w in AMBIG:
        if w in text:
            out.append(('推奨', doc_name, f'曖昧な表現「{w}」'))
    for a in sorted(set(ACRO.findall(text))):
        if a not in glossary and a not in ('OK', 'ID'):
            out.append(('推奨', doc_name, f'用語集にない略語「{a}」（初出で説明する）'))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('memo')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d = json.load(open(a.memo, encoding='utf-8'))
    os.makedirs(a.out, exist_ok=True)
    glossary = {g['term']: g['meaning'] for g in d.get('glossary', [])}
    steps = d.get('steps', [])
    issues = []

    # 手順書
    L = [f"# 手順書：{d['title']}", '', f"- 版：{d.get('version', '1.0')}　／　日付：{d.get('date', '要確認')}　／　担当：{d.get('owner', '要確認')}",
         f"- 対象：{d.get('audience', '新人')}", f"- 目的：{d['purpose']}", '', '## 前提']
    L += [f'- {x}' for x in d.get('premise', [])] or ['- （なし）']
    L += ['', '## 用語']
    L += [f'- **{t}**：{m}' for t, m in glossary.items()] or ['- （なし）']
    L += ['', '## 手順']
    for i, s in enumerate(steps, 1):
        if not s.get('expect'):
            issues.append(('必須', f'手順{i}', '期待される結果がない（見えれば成功、の一文を書く）'))
        if MULTI.search(s['action']):
            issues.append(('推奨', f'手順{i}', '一手順に複数の操作がある可能性（分けられるか確認）'))
        L += [f"### 手順{i}：{s['action']}", f"- 場所：{s.get('where', '要確認')}",
              f"- 期待される結果：{s.get('expect', '要確認')}", f"- 確認：{s.get('check', s.get('expect', '要確認'))}",
              f"- 注意：{s.get('note', 'なし')}", '']
    L += ['## 確認の問い（練習）'] + [f'{i}. {q}' for i, q in enumerate(d.get('questions', []), 1)] + ['']
    L += ['## 困ったとき', f"- 連絡先：{d.get('contact', '要確認')}", '- 次の情報を添えると早く解決します：手順番号、画面、表示された文言。']
    manual = '\n'.join(L) + '\n'
    open(os.path.join(a.out, '手順書.md'), 'w', encoding='utf-8').write(manual)
    issues += lint('手順書', manual, glossary)

    # 上司向け報告
    r = d.get('report', {})
    up = [f"# 報告（上司向け）：{d['title']}", '', f"**結論**：{r.get('conclusion', '要確認')}", '', '## 事実']
    up += [f'- {x}' for x in r.get('facts', [])] or ['- （なし）']
    up += ['', '## 推測（未確認）'] + ([f'- {x}' for x in r.get('guesses', [])] or ['- （なし）'])
    up += ['', '## 判断してほしいこと'] + ([f"- {x['q']}（期限：{x.get('due', '要確認')}／推奨：{x.get('rec', '要確認')}）" for x in r.get('decide', [])] or ['- （なし）'])
    up += ['', '## 次の行動', f"- {r.get('next', '要確認')}"]
    up_txt = '\n'.join(up) + '\n'
    open(os.path.join(a.out, '報告_上司.md'), 'w', encoding='utf-8').write(up_txt)
    issues += lint('報告（上司）', up_txt, glossary)

    # 新人向け報告（今やること＋手順）
    nw = [f"# 今やること：{d['title']}", '', '## まず読むもの', '- 手順書.md（用語の説明から読む）', '', '## 手順']
    nw += [f"{i}. {s['action']}（期待：{s.get('expect', '要確認')}）" for i, s in enumerate(steps, 1)] or ['1. （要確認）']
    nw += ['', '## 分からないとき', f"- {d.get('contact', '要確認')} に、手順番号と表示された文言を伝える。"]
    open(os.path.join(a.out, '報告_新人.md'), 'w', encoding='utf-8').write('\n'.join(nw) + '\n')

    # 自分用
    me = [f"# 自分用チェック：{d['title']}", '']
    me += [f"- [ ] 手順{i}：{s['action']}" for i, s in enumerate(steps, 1)] or ['- [ ] （要確認）']
    me += ['', f"次の行動：{r.get('next', '要確認')}"]
    open(os.path.join(a.out, '自分用チェックリスト.md'), 'w', encoding='utf-8').write('\n'.join(me) + '\n')

    chk = ['# 検査結果', '']
    if issues:
        chk += ['| 判定 | 場所 | 指摘 |', '|---|---|---|'] + [f'| {l} | {w} | {m} |' for l, w, m in issues]
    else:
        chk.append('指摘なし（自動検査の範囲で）')
    chk += ['', '送る前に、推測（未確認）と要確認の箇所を確認してください。']
    open(os.path.join(a.out, '検査結果.md'), 'w', encoding='utf-8').write('\n'.join(chk) + '\n')
    must = sum(1 for x in issues if x[0] == '必須')
    print(f'wrote {a.out}（指摘 {len(issues)} 件、必須 {must} 件）')


if __name__ == '__main__':
    main()
