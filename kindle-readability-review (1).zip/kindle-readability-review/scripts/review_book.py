#!/usr/bin/env python3
"""Kindle本（EPUB / Markdown）を測定し、見やすさ・画像・スマホ表示・内容の指摘を作る。読み取り専用。

使い方:
  python3 review_book.py 原稿.epub --out review.json --md review.md
  python3 review_book.py 原稿.md   --out review.json --md review.md

判定の基準は reference/チェック項目.md と対応する。
"""
import argparse
import json
import re
import zipfile
from html.parser import HTMLParser

MAX_PARA = 300
MAX_TABLE_COLS = 4
MAX_CODE_LINE = 40
MAX_IMG_PX = 600
MAX_IMG_BYTES = 1024 * 1024
BANNED = ['必ず', '誰でも', '絶対', '稼げる', '転職できる']
PLACEHOLDER = r'［入力|\[入力|TODO|FIXME'
SECRET = [r'app-[A-Za-z0-9]{10,}', r'sk-ant-[A-Za-z0-9_\-]{10,}', r'[\w.+-]+@[\w-]+\.[\w.]+']


class Collector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.h = []          # (level, text)
        self.paras = []      # 段落の文字数
        self.imgs = []       # (alt, width)
        self.tables = []     # 列数
        self.pre = []        # コードの行
        self._stack = []
        self._buf = ''
        self._cols = 0
        self._in_table = False
        self._pre_buf = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'li', 'td', 'th'):
            self._stack.append(tag)
            self._buf = ''
        if tag == 'table':
            self._in_table = True
            self._cols = 0
        if tag == 'tr' and self._in_table:
            self._cols_row = 0
        if tag in ('td', 'th') and self._in_table:
            self._cols_row = getattr(self, '_cols_row', 0) + 1
            self._cols = max(self._cols, self._cols_row)
        if tag == 'img':
            w = a.get('width') or re.search(r'width:\s*(\d+)', a.get('style', '') or '')
            w = int(re.sub(r'\D', '', str(w))) if w else None
            self.imgs.append((a.get('alt', None), w, a.get('src', '')))
        if tag == 'pre':
            self._pre_buf = ''

    def handle_endtag(self, tag):
        if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
            self.h.append((int(tag[1]), self._buf.strip()))
        if tag == 'p' or tag == 'li':
            self.paras.append(len(self._buf.strip()))
        if tag == 'table':
            self.tables.append(self._cols)
            self._in_table = False
        if tag == 'pre' and self._pre_buf is not None:
            self.pre += self._pre_buf.splitlines()
            self._pre_buf = None
        if self._stack and self._stack[-1] == tag:
            self._stack.pop()

    def handle_data(self, data):
        if self._pre_buf is not None:
            self._pre_buf += data
        self._buf += data


def check_epub(path):
    z = zipfile.ZipFile(path)
    names = z.namelist()
    html = [n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm'))]
    col = Collector()
    for n in html:
        col.feed(z.read(n).decode('utf-8', 'ignore'))
    opf = next((n for n in names if n.endswith('.opf')), '')
    opf_text = z.read(opf).decode('utf-8', 'ignore') if opf else ''
    css = ' '.join(z.read(n).decode('utf-8', 'ignore') for n in names if n.endswith('.css'))
    imgs_bytes = {n: z.getinfo(n).file_size for n in names if re.search(r'\.(png|jpe?g|gif|svg)$', n, re.I)}
    text = ' '.join(z.read(n).decode('utf-8', 'ignore') for n in html)
    return dict(headings=col.h, paras=col.paras, imgs=col.imgs, tables=col.tables, pre=col.pre,
                fixed='rendition:layout" content="pre-paginated' in opf_text or 'pre-paginated' in opf_text,
                px_fonts=bool(re.search(r'font-size:\s*\d+px', css)), img_bytes=imgs_bytes,
                toc=any('nav' in n.lower() or 'toc' in n.lower() for n in names), text=text)


def check_md(path):
    t = open(path, encoding='utf-8').read()
    heads = [(len(m.group(1)), m.group(2).strip()) for m in re.finditer(r'^(#{1,6})\s*(.*)$', t, re.M)]
    paras = [len(p.strip()) for p in re.split(r'\n\s*\n', t) if p.strip() and not p.strip().startswith(('#', '|', '```', '-', '*', '>'))]
    imgs = [(m.group(1) or None, None, m.group(2)) for m in re.finditer(r'!\[([^\]]*)\]\(([^)]+)\)', t)]
    tables = []
    for block in re.findall(r'((?:^\|.*\|\s*$\n?)+)', t, re.M):
        rows = [r for r in block.strip().splitlines() if r.strip()]
        if rows:
            tables.append(rows[0].count('|') - 1)
    pre = []
    for block in re.findall(r'```.*?\n(.*?)```', t, re.S):
        pre += block.splitlines()
    return dict(headings=heads, paras=paras, imgs=imgs, tables=tables, pre=pre, fixed=False, px_fonts=False,
                img_bytes={}, toc=bool(re.search(r'目次', t)), text=t)


def judge(d, path):
    F = []
    def add(i, cat, level, where, finding, value, basis, fix):
        F.append(dict(id=f'K{len(F) + 1:03d}', check=i, category=cat, level=level, where=where, finding=finding,
                      measured=value, basis=basis, fix=fix))
    # 見出し
    prev = 0
    for lv, txt in d['headings']:
        if prev and lv > prev + 1:
            add('R-01', '見やすさ', '推奨', txt[:20], f'見出しの階層が飛んでいる（h{prev}→h{lv}）', f'h{prev}→h{lv}', 'チェック項目 R-01', '中間の見出しを補う、または階層を直す')
        if not txt:
            add('R-03', '見やすさ', '推奨', '見出し', '空の見出しがある', '空', 'チェック項目 R-03', '見出しの文字を書く、または削除する')
        prev = lv
    for i, p in enumerate(d['paras'], 1):
        if p > MAX_PARA:
            add('R-02', '見やすさ', '推奨', f'段落{i}', f'段落が長い（{p}字）', f'{p}字', 'チェック項目 R-02（300字以内の目安）', '段落を分ける')
    if not d['toc']:
        add('R-04', '見やすさ', '推奨', '全体', '目次（ナビゲーション）が見当たらない', 'なし', 'チェック項目 R-04', '目次を入れる')
    for alt, w, src in d['imgs']:
        if not alt:
            add('I-01', '画像', '推奨', src, '画像に代替テキストがない', '空', 'チェック項目 I-01', 'alt（代替テキスト）を書く')
        if w and w > MAX_IMG_PX:
            add('I-02', '画像', '必須', src, f'画像の指定幅が端末幅を超える（{w}px）', f'{w}px', 'チェック項目 I-02', '幅を端末幅以下に変える')
    for n, size in d.get('img_bytes', {}).items():
        if size > MAX_IMG_BYTES:
            add('I-03', '画像', '推奨', n, f'画像が大きい（{size // 1024}KB）', f'{size // 1024}KB', 'チェック項目 I-03', '圧縮する')
    for cols in d['tables']:
        if cols > MAX_TABLE_COLS:
            add('M-01', 'スマホ', '必須', '表', f'表が{cols}列あり、スマホで横に溢れやすい', f'{cols}列', 'チェック項目 M-01（4列以下）', '列を減らす、分割する、縦組みにする')
    for line in d['pre']:
        if len(line) > MAX_CODE_LINE:
            add('M-02', 'スマホ', '必須', 'コード', f'コードの行が長い（{len(line)}字）', f'{len(line)}字', 'チェック項目 M-02（40字以内）', '改行して収める')
            break
    if d['px_fonts']:
        add('M-03', 'スマホ', '推奨', 'CSS', '文字サイズがpxの固定値', 'px', 'チェック項目 M-03', 'em・%に変える')
    if d['fixed']:
        add('M-04', 'スマホ', '必須', 'OPF', '固定レイアウトの指定がある（スマホで読みにくい）', '固定', 'チェック項目 M-04', 'リフローに変える')
    t = d['text']
    for w in BANNED:
        if w in t:
            add('C-03', '内容', '推奨', w, f'保証表現「{w}」', w, 'チェック項目 C-03', '条件つきの表現に言い換える')
    if re.search(PLACEHOLDER, t):
        add('C-02', '内容', '必須', '全体', '未完成の表記（［入力］・TODO等）が残っている', '残存', 'チェック項目 C-02', '埋める、または削除する')
    for pat in SECRET:
        if re.search(pat, t):
            add('C-01', '内容', '必須', '全体', '機密らしき文字列が含まれている', 'パターン一致', 'チェック項目 C-01', '該当を削除し、キーは無効化する')
            break
    if '公式' in t and not re.search(r'https?://', t):
        add('C-04', '内容', '推奨', '全体', '「公式」の記載があるがURLが見当たらない', '0件', 'チェック項目 C-04', '出典URLを添える')
    if not re.search(r'確認日|対象.*版', t):
        add('C-05', '内容', '推奨', '全体', '対象の版・確認日が見当たらない', 'なし', 'チェック項目 C-05', '冒頭に記載する')
    order = {'必須': 0, '推奨': 1}
    F.sort(key=lambda x: (order[x['level']], x['id']))
    must = sum(1 for f in F if f['level'] == '必須')
    rec = len(F) - must
    verdict = '要修正' if must else ('概ね良好（改善推奨）' if rec else '良好')
    phone = '不可' if any(f['check'] in ('M-01', 'M-02', 'M-04') for f in F) else ('要改善' if any(f['category'] == 'スマホ' for f in F) else '良')
    return dict(file=path, verdict=verdict, phone=phone, counts=dict(必須=must, 推奨=rec), findings=F)


def to_md(r):
    L = [f"# Kindle本 レビュー（{r['file']}）", '', f"**総合：{r['verdict']}**　／　**スマホでの読みやすさ：{r['phone']}**", '',
         f"必須 {r['counts']['必須']}件・推奨 {r['counts']['推奨']}件（測定に基づく。審査の結果は保証されない）", '',
         '| ID | 観点 | 判定 | 場所 | 指摘 | 測定値 | 根拠 | 修正案 |', '|---|---|---|---|---|---|---|---|']
    for f in r['findings']:
        L.append(f"| {f['id']} | {f['category']} | {f['level']} | {f['where']} | {f['finding']} | {f['measured']} | {f['basis']} | {f['fix']} |")
    if not r['findings']:
        L.append('| - | - | - | - | 指摘なし | - | - | - |')
    L += ['', '## 承認のお願い', '修正してよいIDを指定してください（例：K001,K003）。指定がないものは変更しません。',
          '', '## 実機確認', 'Kindle Previewer や実機の Kindle アプリで、スマホの縦画面の表示を確かめてください。']
    return '\n'.join(L) + '\n'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('book')
    ap.add_argument('--out', default='')
    ap.add_argument('--md', default='')
    a = ap.parse_args()
    d = check_epub(a.book) if a.book.lower().endswith('.epub') else check_md(a.book)
    r = judge(d, a.book)
    if a.out:
        open(a.out, 'w', encoding='utf-8').write(json.dumps(r, ensure_ascii=False, indent=2))
    if a.md:
        open(a.md, 'w', encoding='utf-8').write(to_md(r))
    print(f"総合：{r['verdict']}／スマホ：{r['phone']}（必須 {r['counts']['必須']}・推奨 {r['counts']['推奨']}）")


if __name__ == '__main__':
    main()
