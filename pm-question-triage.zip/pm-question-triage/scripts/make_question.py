#!/usr/bin/env python3
"""メンバーの雑メモ（memo.json）を、PMへの質問（型つき）に変換し、送る前の検査をする。

使い方:
  python3 make_question.py memo.json --out ./出力

memo.json の形は tests/sample_memo.json を参照。
- 判断が必要な項目だけを質問にする。報告・自己解決は別の欄に分ける。
- 調べた内容がない、選択肢がない、期限がない質問は、警告して送信前に直すよう求める。
"""
import argparse
import json
import os
import re

PII = [(r'[\w.+-]+@[\w-]+\.[\w.]+', 'メールアドレス'), (r'\d{2,4}-\d{2,4}-\d{3,4}', '電話番号らしき数字')]
EMOTION = ['ムカつく', '最悪', 'なんで', 'あの人', 'ひどい', 'きつい']
PRIORITY = {'今日': 0, '今週': 1, '急ぎでない': 2}


def check(q, idx):
    issues = []
    if not q.get('researched'):
        issues.append('調べた内容がない（先に調べてから聞く）')
    if not q.get('options') or len(q.get('options', [])) < 2:
        issues.append('選択肢が2つ以上ない')
    if not q.get('deadline'):
        issues.append('期限がない')
    if not q.get('recommend'):
        issues.append('自分の推奨案がない')
    text = json.dumps(q, ensure_ascii=False)
    for pat, label in PII:
        if re.search(pat, text):
            issues.append(f'{label}が含まれる（削除）')
    for w in EMOTION:
        if w in text:
            issues.append(f'感情的な表現「{w}」（業務の事実だけに直す）')
    if q.get('question', '').count('、') > 3:
        issues.append('質問が長い（判断は一つに絞る）')
    return issues


def render(q):
    opts = q.get('options', [])
    lines = [f"【質問】{q['question']}"]
    if q.get('background'):
        lines.append(f"背景：{q['background']}")
    lines.append(f"調べたこと：{q.get('researched') or '（未記入：先に調べる）'}")
    if opts:
        lines.append('選択肢：')
        lines += [f"  {chr(65 + i)}案：{o['name']}（利点：{o.get('pro', '要確認')}／懸念：{o.get('con', '要確認')}）" for i, o in enumerate(opts)]
    lines.append(f"私の推奨：{q.get('recommend') or '（未記入）'}")
    lines.append(f"期限：{q.get('deadline') or '（未記入）'}" + (f"（遅れると：{q['impact']}）" if q.get('impact') else ''))
    lines.append(f"PMの時間の目安：{q.get('pm_time', '1分で判断できます')}")
    return '\n'.join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('memo')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d = json.load(open(a.memo, encoding='utf-8'))
    os.makedirs(a.out, exist_ok=True)
    questions = [q for q in d.get('items', []) if q.get('kind') == '質問']
    reports = [q for q in d.get('items', []) if q.get('kind') == '報告']
    selfsolve = [q for q in d.get('items', []) if q.get('kind') == '自分で解決']
    questions.sort(key=lambda q: PRIORITY.get(q.get('priority', '今週'), 1))
    checks = []
    for i, q in enumerate(questions, 1):
        checks.append((q['question'], check(q, i)))
    ready_n = len([q for q in questions if not check(q, 0)])
    lines = ['# PMへの質問一覧', '', f"送る件数：{min(ready_n, 3)} 件（1回は3件まで。残りは次回）", '']
    for pr in ['今日', '今週', '急ぎでない']:
        group = [q for q in questions if q.get('priority', '今週') == pr]
        if group:
            lines += [f'## {pr}', ''] + [f"- {q['question']}" for q in group] + ['']
    if reports:
        lines += ['## 報告（質問ではない）', ''] + [f"- {r['text']}" for r in reports] + ['']
    if selfsolve:
        lines += ['## 自分で解決すること（PMに聞かない）', ''] + [f"- {s['text']}（方法：{s.get('how', '要確認')}）" for s in selfsolve] + ['']
    open(os.path.join(a.out, '質問一覧.md'), 'w', encoding='utf-8').write('\n'.join(lines) + '\n')

    ready = [q for q in questions if not check(q, 0)]
    send = ready[:3]
    held = [q['question'] for q in questions if check(q, 0)]
    slack = '\n\n'.join(render(q) for q in send) or '（送れる質問はありません。自己チェックを先に直してください）'
    if held:
        slack += '\n\n（未完成のため送信から除外：' + '、'.join(held) + '）'
    open(os.path.join(a.out, 'slack_質問.txt'), 'w', encoding='utf-8').write(slack + '\n')

    chk = ['# 送る前の自己チェック', '']
    blocked = 0
    for question, issues in checks:
        if issues:
            blocked += 1
            chk.append(f"- ✗ {question}")
            chk += [f'    - {x}' for x in issues]
        else:
            chk.append(f"- ■ {question}")
    if not checks:
        chk.append('- 質問はありません')
    chk += ['', f'直す必要のある質問：{blocked} 件。すべて ■ になってから送ってください。']
    open(os.path.join(a.out, '自己チェック.md'), 'w', encoding='utf-8').write('\n'.join(chk) + '\n')
    print(f'wrote {a.out}（質問 {len(questions)} 件、要修正 {blocked} 件）')


if __name__ == '__main__':
    main()
