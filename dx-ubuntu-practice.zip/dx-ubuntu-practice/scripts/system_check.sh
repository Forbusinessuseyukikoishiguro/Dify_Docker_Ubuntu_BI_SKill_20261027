#!/usr/bin/env bash
# Ubuntu の状態を点検する（読み取り専用。値の変更はしない）
# 使い方: bash system_check.sh > 点検結果.txt
set -u

echo "== OS =="
if [ -r /etc/os-release ]; then . /etc/os-release; echo "${PRETTY_NAME:-unknown}"; fi
uname -r

echo; echo "== ディスク（使用率 80% 以上を要確認）=="
df -P -x tmpfs -x devtmpfs | awk 'NR>1 {gsub("%","",$5); flag=($5+0>=80)?"  <- 要確認":""; print $6, $5"%"flag}'

echo; echo "== メモリ =="
free -h | sed -n '1,2p'

echo; echo "== 自動更新（unattended-upgrades）=="
if dpkg -s unattended-upgrades >/dev/null 2>&1; then echo "導入済み"; else echo "未導入（要確認）"; fi

echo; echo "== 更新可能なパッケージ数 =="
apt list --upgradable 2>/dev/null | tail -n +2 | wc -l

echo; echo "== ファイアウォール（ufw）=="
if command -v ufw >/dev/null 2>&1; then sudo -n ufw status 2>/dev/null | head -n 5 || echo "権限なしで確認不可"; else echo "ufw 未導入"; fi

echo; echo "== SSH 設定（主要項目）=="
if [ -r /etc/ssh/sshd_config ]; then
  grep -Ei '^\s*(PermitRootLogin|PasswordAuthentication|PubkeyAuthentication|Port)\b' /etc/ssh/sshd_config || echo "（明示の設定なし：既定値）"
else
  echo "sshd_config を読めない（権限または未導入）"
fi

echo; echo "== Docker =="
if command -v docker >/dev/null 2>&1; then
  docker --version 2>/dev/null || true
  if id -nG 2>/dev/null | grep -qw docker; then echo "現在のユーザーは docker グループ：はい（root 相当の権限に注意）"; else echo "現在のユーザーは docker グループ：いいえ"; fi
else
  echo "docker 未導入"
fi

echo; echo "== 時刻同期 =="
timedatectl 2>/dev/null | grep -Ei 'time zone|synchronized' || echo "確認不可"

echo; echo "== 失敗したサービス =="
systemctl --failed --no-legend 2>/dev/null | head -n 10 || echo "確認不可"

echo; echo "（この点検は読み取りのみ。変更は承認後に行う）"
